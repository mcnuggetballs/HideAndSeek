## Installation Guide

1. **Install a version of Conda:**
	 - Miniconda install steps: https://www.anaconda.com/docs/getting-started/miniconda/install/overview

2. **Install Python 3.10.12 using Conda environment:**
	 - Other versions of Python __will not__ work!
	 - **macOS (Terminal) / Windows (Anaconda Prompt):**
	 	```bash
		conda create -n mlagents python=3.10.12
		```

3. **Activate the Conda environment:**
	 - **macOS/Windows:**
		 ```bash
		 conda activate mlagents
		 ```

4. **Install dependencies:**
	- **macOS:**
		```bash
		conda install "grpcio=1.48.2" -c conda-forge
		pip install mlagents==1.1.0
		pip install torch==2.1.1 onnx==1.15.0 protobuf==3.20.3
		```
	- **Windows:**
		```powershell
		pip3 install torch~=2.2.1 --index-url https://download.pytorch.org/whl/cu121
		pip install mlagents==1.1.0
		pip install "setuptools<82.0.0"
		```
Reference: https://docs.unity3d.com/Packages/com.unity.ml-agents@4.0/manual/Installation.html


## Quick Start Guide

**To start ml-agents server for training:**

1. **Open the Unity project folder in your terminal, or change directory to it:**
	 - **macOS/Windows:**
		 ```bash
		 cd /path/to/project/folder/root
		 ```

2. **Activate the Conda environment:**
	 - **macOS/Windows:**
		 ```bash
		 conda activate mlagents
		 ```

3. **Start a new training run or resume a previous one:**
	 - **macOS/Windows:**
		 ```bash
		# Start a new run
		mlagents-learn --run-id=<enter_run_id_here>

		# Force overwrite a particular run
		mlagents-learn --run-id=<enter_run_id_here> --force

		# Resume a previous run
		mlagents-learn --run-id=<enter_run_id_here> --resume

		# Specify configuration file
		mlagents-learn /path/to/config.yaml --run-id=<enter_run_id_here>
		 ```
	 - **If the config isn't picked up** (default settings, wrong behavior name, or a "configuration file
	   not found" error), pass it explicitly:
		 ```bash
		 mlagents-learn config/MultiBlueAgentSearch.yaml --run-id=<enter_run_id_here>
		 ```
	 - **Windows:** If PyTorch does not support your GPU's CUDA capability, run the following and try again.
	 	- **Powershell:**
		 ```powershell
		 $env:CUDA_VISIBLE_DEVICES = "-1"
		 ```
		 - **Command Prompt / Anaconda Prompt:**
		 ```powershell
		 set CUDA_VISIBLE_DEVICES=-1
		 ```

4. **Open** ```Assets/Scenes/TrainingScene.unity``` — the multi-area training scene.

5. **Check the agent is not pinned to inference.** Select ```Assets/Prefabs/New/BlueAgent.prefab``` and
   confirm **Behavior Parameters → Behavior Type** is ```Default```, not ```Inference Only```. On
   ```Default``` the agent uses the trainer when one is connected; on ```Inference Only``` it ignores
   the trainer and keeps running the old model, so training appears to connect but never learns.
   A **Model** may stay assigned — it is ignored while training.

6. **Click 'Play' in Unity to start training.**

7. **After successful training, move the model file** ```Team Search.onnx``` **from** ```/results/run_id/``` **to** ```/Assets/AI Models```.

**To perform inference of a trained model:**

Runs entirely in Unity — no terminal, no Conda.

1. **Copy** ```Team Search.onnx``` from ```/results/<run_id>/``` into ```/Assets/AI Models```.

2. **Open** ```Assets/Scenes/TestingScene.unity``` — one area, episodes never end, so agents run
   continuously instead of resetting to spawn.

3. **Select** ```Assets/Prefabs/New/BlueAgent.prefab``` and set **Behavior Parameters → Model** to the
   model from step 1. Leave **Behavior Type** on ```Default``` — it uses the trainer when one is
   connected and the model when one is not, so the same prefab serves both.

4. **Click 'Play'.**

**Notes for inference runs:**



- **Observation shapes must match the model**, or Unity throws ```Observation shapes incompatible``` on
  Play. Current setup: ```21x21``` local grid (```radius 5```, ```supersample 2```), ```4```-value
  vector, buffer sensors ```9x2``` (teammates) and ```7x5``` (red agents), branches ```[4, 5]```.

- **Press** ```G``` for the local grid sensor overlay (green = free, red = wall, cyan = agent).

- **The testing scene never writes** ```curriculum_progress_v2.json``` — the curriculum is only
  consulted when an episode ends, and here they don't. Evaluating in ```TrainingScene``` *will* advance
  the curriculum; set **Strategy** to ```Fixed``` or back up the file first.