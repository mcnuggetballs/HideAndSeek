namespace RedVsBlue
{
    public interface IInfluenceLayer
    {
        InfluenceMap.LayerTag LayerType { get; }
        void Initialise(int rows, int cols, InfluenceMap influenceMap);
        void UpdateLayer();
        void RefreshLayer();
    }
}
