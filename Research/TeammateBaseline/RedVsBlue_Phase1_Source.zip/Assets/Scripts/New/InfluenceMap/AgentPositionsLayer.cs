using UnityEngine;
using System.Collections.Generic;

namespace RedVsBlue
{
    public class AgentPositionsLayer : IInfluenceLayer
    {
        private int[,] _tilesData;

        // Each agent's last-known tile, so SetData only ever touches the (at most two) tiles that actually
        // changed this call instead of redrawing the whole grid.
        private readonly Dictionary<int, Vector2Int> _agentPositions = new();

        private InfluenceMap _influenceMap;
        public InfluenceMap.LayerTag LayerType => InfluenceMap.LayerTag.AgentPositions;

        public void Initialise(int rows, int cols, InfluenceMap influenceMap)
        {
            _influenceMap = influenceMap;
            _tilesData = new int[rows, cols];
        }

        public void SetData(Vector2Int agentTilePos, int agentId)
        {
            if (_agentPositions.TryGetValue(agentId, out Vector2Int oldPos))
            {
                if (oldPos == agentTilePos) return; // agent hasn't moved to a new tile — nothing to update

                // Only clear the old tile if it's still marked as this agent — another agent may have
                // already moved onto it and claimed it since, in which case leave it alone.
                if (_tilesData[oldPos.y, oldPos.x] == agentId)
                {
                    _tilesData[oldPos.y, oldPos.x] = 0;
                    if (_influenceMap != null)
                        _influenceMap.SetTileColour(oldPos.x, oldPos.y, InfluenceMap.BaseColour, LayerType);
                }
            }

            _agentPositions[agentId] = agentTilePos;
            _tilesData[agentTilePos.y, agentTilePos.x] = agentId;
            if (_influenceMap != null)
                _influenceMap.SetTileColour(agentTilePos.x, agentTilePos.y, InfluenceMap.HighlightedColour, LayerType);
        }

        public int GetData(Vector2Int agentTilePos)
        {
            return _tilesData[agentTilePos.y, agentTilePos.x];
        }

        public Dictionary<int, Vector2Int> GetAllAgentPositions()
        {
            return _agentPositions;
        }

        public void UpdateLayer() {}

        public void RefreshLayer()
        {
            for (int row = 0; row < _tilesData.GetLength(0); row++)
            {
                for (int col = 0; col < _tilesData.GetLength(1); col++)
                {
                    if (_tilesData[row, col] == 0)
                    {
                        _influenceMap?.SetTileColour(col, row, InfluenceMap.BaseColour, LayerType);
                    }
                    else
                    {
                        _influenceMap?.SetTileColour(col, row, InfluenceMap.HighlightedColour, LayerType);
                    }
                }
            }
        }
    }
}
