using UnityEngine;
using System.Collections.Generic;

namespace RedVsBlue
{
    public class TimeSinceLastSeenLayer : IInfluenceLayer
    {
        private const float MaxSeenAge = 30f;

        private float[,] _tilesData;
        private InfluenceMap _influenceMap;
        private HashSet<Vector2Int> _activeTiles = new();
        private WasSeenLayer _wasSeenLayer;
        private AgentPositionsLayer _agentPositionsLayer;

        public InfluenceMap.LayerTag LayerType => InfluenceMap.LayerTag.TimeSinceLastSeen;

        public void Initialise(int rows, int cols, InfluenceMap influenceMap)
        {
            _influenceMap = influenceMap;
            _tilesData = new float[rows, cols];

            for (int row = 0; row < rows; row++)
                for (int col = 0; col < cols; col++)
                    _tilesData[row, col] = -1f;

            _wasSeenLayer = _influenceMap.GetLayer(InfluenceMap.LayerTag.WasSeen) as WasSeenLayer;
            _agentPositionsLayer = _influenceMap.GetLayer(InfluenceMap.LayerTag.AgentPositions) as AgentPositionsLayer;
        }

        public (int totalObservedCount, int totalNewlyObservedCount, HashSet<int> observedAgentsInFOV) UpdateLOS(Vector2Int pos, int radius, float startAngle, float endAngle, int agentId)
        {
            int totalObservedCount = 0, totalNewlyObservedCount = 0;

            HashSet<Vector2Int> arcCells = GetArcCells(pos, radius, startAngle, endAngle);
            HashSet<int> observedAgentsInFOV = new();

            foreach (Vector2Int cell in arcCells)
            {
                (int observedCount, int newlyObservedCount) = RaycastLOSCheck2D(pos, cell, agentId, observedAgentsInFOV);
                totalObservedCount += observedCount;
                totalNewlyObservedCount += newlyObservedCount;
            }

            return (totalObservedCount, totalNewlyObservedCount, observedAgentsInFOV);
        }

        public void UpdateLayer()
        {
            foreach (Vector2Int tilePos in _activeTiles)
            {
                int col = tilePos.x;
                int row = tilePos.y;

                if (_tilesData[row, col] < 0f) {
                    _influenceMap?.SetTileColour(col, row, InfluenceMap.BaseColour, LayerType);
                    continue;
                }

                float age = Time.time - _tilesData[row, col];
                float t = Mathf.Clamp01(age / MaxSeenAge);
                Color colour = Color.Lerp(InfluenceMap.HighlightedColour, InfluenceMap.BaseColour, t);

                _influenceMap?.SetTileColour(col, row, colour, LayerType);
            }

            _activeTiles.RemoveWhere(tilePos => Time.time - _tilesData[tilePos.y, tilePos.x] >= MaxSeenAge);
        }

        public void RefreshLayer()
        {
            for (int row = 0; row < _tilesData.GetLength(0); row++)
            {
                for (int col = 0; col < _tilesData.GetLength(1); col++)
                {
                    // Add each Vector2Int coordinate into _activeTiles, will refresh the entire layer at next update
                    _activeTiles.Add(new Vector2Int(col, row));
                }
            }
        }

        private HashSet<Vector2Int> GetArcCells(Vector2Int center, int radius, float startAngle, float endAngle)
        {
            var cells = new HashSet<Vector2Int>();

            startAngle %= 360f;
            if (startAngle < 0f) startAngle += 360f;
            endAngle %= 360f;
            if (endAngle < 0f) endAngle += 360f;

            if (radius <= 0) return cells;

            void AddCell(Vector2Int cell)
            {
                if (!cells.Add(cell)) return;

                // Repair diagonal-only connections, e.g. XO/OX -> XO/XX.
                for (int dr = -1; dr <= 1; dr += 2)
                {
                    for (int dc = -1; dc <= 1; dc += 2)
                    {
                        Vector2Int diagonal = new Vector2Int(cell.x + dc, cell.y + dr);
                        if (!cells.Contains(diagonal)) continue;

                        Vector2Int bridgeA = new Vector2Int(diagonal.x, cell.y);
                        Vector2Int bridgeB = new Vector2Int(cell.x, diagonal.y);
                        if (cells.Contains(bridgeA) || cells.Contains(bridgeB)) continue;

                        int aDist = (bridgeA.x - center.x) * (bridgeA.x - center.x)
                            + (bridgeA.y - center.y) * (bridgeA.y - center.y);
                        int bDist = (bridgeB.x - center.x) * (bridgeB.x - center.x)
                            + (bridgeB.y - center.y) * (bridgeB.y - center.y);

                        AddCell(aDist <= bDist ? bridgeA : bridgeB);
                    }
                }
            }

            void TryAddCirclePoint(int offsetCol, int offsetRow)
            {
                float angle = Mathf.Atan2(offsetCol, -offsetRow) * Mathf.Rad2Deg;
                if (angle < 0f) angle += 360f;

                bool inArc = startAngle <= endAngle
                    ? angle >= startAngle && angle <= endAngle
                    : angle >= startAngle || angle <= endAngle;

                if (inArc)
                    AddCell(new Vector2Int(center.x + offsetCol, center.y + offsetRow));
            }

            // Midpoint circle algorithm: generate only circumference cells.
            int x = radius;
            int y = 0;
            int p = 1 - radius;

            while (x >= y)
            {
                TryAddCirclePoint( x,  y);
                TryAddCirclePoint( y,  x);
                TryAddCirclePoint(-y,  x);
                TryAddCirclePoint(-x,  y);
                TryAddCirclePoint(-x, -y);
                TryAddCirclePoint(-y, -x);
                TryAddCirclePoint( y, -x);
                TryAddCirclePoint( x, -y);

                y++;
                if (p <= 0) p += 2 * y + 1;
                else
                {
                    x--;
                    p += 2 * (y - x) + 1;
                }
            }

            return cells;
        }

        public (int observedCount, int newlyObservedCount) RaycastLOSCheck2D(Vector2Int startPoint, Vector2Int endPoint, int agentId, HashSet<int> observedAgentsInFOV)
        {
            int x0 = startPoint.x;
            int y0 = startPoint.y;
            int x1 = endPoint.x;
            int y1 = endPoint.y;

            int dx = Mathf.Abs(x1 - x0);
            int dy = Mathf.Abs(y1 - y0);
            int sx = x0 < x1 ? 1 : -1;
            int sy = y0 < y1 ? 1 : -1;
            int error = dx - dy;

            bool newlyObserved;

            int newlyObservedCount = 0;
            int observedCount = 0;
            int agentInCellId;

            while (true)
            {
                // Break if the cell is a wall or out of bounds -- the grid is the authority on
                // walkability (IsWalkable also bounds-checks), not whether a tile Renderer exists.
                if (!_influenceMap.IsWalkable(y0, x0)) break;

                // Observe the cell and update its last seen time
                _activeTiles.Add(new Vector2Int(x0, y0));
                _tilesData[y0, x0] = Time.time;

                // Check if observed other agents in this cell
                agentInCellId = _agentPositionsLayer.GetData(new Vector2Int(x0, y0));
                if (agentInCellId != agentId && agentInCellId != 0 && !observedAgentsInFOV.Contains(agentInCellId))
                {
                    // Add agent observation into hash set
                    observedAgentsInFOV.Add(agentInCellId);
                }
                newlyObserved = _wasSeenLayer.SetData(new Vector2Int(x0, y0));

                if (newlyObserved)
                {
                    newlyObservedCount++;
                }
                observedCount++;

                // Break if we have reached the end point
                if (x0 == x1 && y0 == y1) break;

                int error2 = 2 * error;
                if (error2 > -dy)
                {
                    error -= dy;
                    x0 += sx;
                }

                if (error2 < dx)
                {
                    error += dx;
                    y0 += sy;
                }
            }

            return (observedCount, newlyObservedCount);
        }
    }
}
