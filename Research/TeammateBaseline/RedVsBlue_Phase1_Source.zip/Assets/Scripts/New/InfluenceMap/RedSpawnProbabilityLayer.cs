using System.Collections.Generic;
using UnityEngine;

namespace RedVsBlue
{
    // Visualises the inverse-count spawn-probability weighting (see
    // MultiAgentEnvironmentManager.SpawnRedAgents) on top of the valid spawn band computed by
    // ComputeValidRedSpawnCells: white = probability 0 (outside the band, or unwalkable -- can never be
    // spawned on), red = in the band, with intensity proportional to that cell's relative spawn
    // probability. A cell caught many times fades toward white (low but never quite zero probability,
    // since inverse-count weighting never fully excludes a cell) even though it's technically still
    // spawnable; a never-caught cell in the band reads as full, pure red.
    public class RedSpawnProbabilityLayer : IInfluenceLayer
    {
        private float[,] _tilesData; // normalised [0,1] probability; -1 = not in the spawn pool at all
        private InfluenceMap _influenceMap;
        public InfluenceMap.LayerTag LayerType => InfluenceMap.LayerTag.RedSpawnProbability;

        public void Initialise(int rows, int cols, InfluenceMap influenceMap)
        {
            _influenceMap = influenceMap;
            _tilesData = new float[rows, cols];
            for (int row = 0; row < rows; row++)
                for (int col = 0; col < cols; col++)
                    _tilesData[row, col] = -1f;
        }

        // cellWeights: every cell currently in the valid spawn pool, mapped to its raw inverse-count
        // weight (1 / (1 + catchCount)). Normalised here against the pool's own maximum weight purely for
        // display, so the least-caught cell(s) always read as full red regardless of the absolute weight
        // values -- the actual sampling in SpawnRedAgents normalises against the weight *sum* instead,
        // which is the correct normalisation for a probability distribution but would wash out the colours
        // (typically small fractions) if used here.
        public void SetSpawnProbabilities(Dictionary<(int row, int col), float> cellWeights)
        {
            for (int row = 0; row < _tilesData.GetLength(0); row++)
                for (int col = 0; col < _tilesData.GetLength(1); col++)
                    _tilesData[row, col] = -1f;

            float maxWeight = 0f;
            foreach (float weight in cellWeights.Values)
                if (weight > maxWeight) maxWeight = weight;

            if (maxWeight > 0f)
            {
                foreach (var kvp in cellWeights)
                    _tilesData[kvp.Key.row, kvp.Key.col] = kvp.Value / maxWeight;
            }

            RefreshLayer();
        }

        public void UpdateLayer() { }

        public void RefreshLayer()
        {
            for (int row = 0; row < _tilesData.GetLength(0); row++)
            {
                for (int col = 0; col < _tilesData.GetLength(1); col++)
                {
                    float normalised = _tilesData[row, col];
                    Color colour = normalised < 0f
                        ? InfluenceMap.BaseColour
                        : Color.Lerp(InfluenceMap.BaseColour, InfluenceMap.HighlightedColour, normalised);
                    _influenceMap?.SetTileColour(col, row, colour, LayerType);
                }
            }
        }
    }
}
