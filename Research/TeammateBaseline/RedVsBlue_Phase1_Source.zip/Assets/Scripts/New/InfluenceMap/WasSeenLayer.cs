using UnityEngine;

namespace RedVsBlue
{
    public class WasSeenLayer : IInfluenceLayer
    {

        private int[,] _tilesData;
        private InfluenceMap _influenceMap;
        private int _seenCount;
        public InfluenceMap.LayerTag LayerType => InfluenceMap.LayerTag.WasSeen;

        public void Initialise(int rows, int cols, InfluenceMap influenceMap)
        {
            _influenceMap = influenceMap;
            _tilesData = new int[rows, cols];
            _seenCount = 0;
        }

        public bool SetData(Vector2Int seenTile)
        {
            // If tile has not been seen before
            if (_tilesData[seenTile.y, seenTile.x] == 0)
            {
                // Mark tile as seen and update the influence map
                _tilesData[seenTile.y, seenTile.x] = 1;
                _seenCount++;
                _influenceMap?.SetTileColour(seenTile.x, seenTile.y, InfluenceMap.HighlightedColour, LayerType);
                return true;
            }
            return false;
        }

        public bool GetData(int row, int col) => _tilesData[row, col] != 0;

        public int GetSeenCount() => _seenCount;

        public void UpdateLayer() {}

        public void RefreshLayer()
        {
            for (int row = 0; row < _tilesData.GetLength(0); row++)
            {
                for (int col = 0; col < _tilesData.GetLength(1); col++)
                {
                    if (_tilesData[row, col] == 0)
                    {
                        _influenceMap?.SetTileColour(col, row, InfluenceMap.BaseColour, LayerType);
                    }
                    else
                    {
                        _influenceMap?.SetTileColour(col, row, InfluenceMap.HighlightedColour, LayerType);
                    }
                }
            }
        }
    }
}
