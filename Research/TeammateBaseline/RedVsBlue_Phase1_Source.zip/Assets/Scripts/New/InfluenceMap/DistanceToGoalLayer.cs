using UnityEngine;

namespace RedVsBlue
{
    public class DistanceToGoalLayer : IInfluenceLayer
    {
        private float[,] _tilesData;
        private InfluenceMap _influenceMap;

        public InfluenceMap.LayerTag LayerType => InfluenceMap.LayerTag.DistanceToGoal;

        public void Initialise(int rows, int cols, InfluenceMap influenceMap)
        {
            _influenceMap = influenceMap;
            _tilesData = new float[rows, cols];

            for (int row = 0; row < rows; row++)
                for (int col = 0; col < cols; col++)
                    _tilesData[row, col] = -1f;
        }

        public void SetData(float[,] distances)
        {
            _tilesData = distances;
            RefreshLayer();
        }

        public void UpdateLayer() {}

        public void RefreshLayer()
        {
            for (int row = 0; row < _tilesData.GetLength(0); row++)
            {
                for (int col = 0; col < _tilesData.GetLength(1); col++)
                {
                    float distance = _tilesData[row, col];
                    Color colour = distance < 0f
                        ? InfluenceMap.BaseColour
                        : Color.Lerp(InfluenceMap.HighlightedColour, InfluenceMap.BaseColour, distance);

                    _influenceMap?.SetTileColour(col, row, colour, LayerType);
                }
            }
        }
    }
}
