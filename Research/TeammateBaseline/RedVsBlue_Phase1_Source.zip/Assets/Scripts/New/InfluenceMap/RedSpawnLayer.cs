using System.Collections.Generic;
using UnityEngine;

namespace RedVsBlue
{
    // Visualises MultiAgentEnvironmentManager.ComputeValidRedSpawnCells()'s result: every walkable tile
    // currently within [redMinDistanceFromBlue, redMaxDistanceFromBlue] hops of a blue agent, i.e. where a
    // red agent could actually spawn this episode. Debug-only -- doesn't feed any observation or reward.
    public class RedSpawnLayer : IInfluenceLayer
    {
        private bool[,] _tilesData;
        private InfluenceMap _influenceMap;
        public InfluenceMap.LayerTag LayerType => InfluenceMap.LayerTag.RedSpawn;

        public void Initialise(int rows, int cols, InfluenceMap influenceMap)
        {
            _influenceMap = influenceMap;
            _tilesData = new bool[rows, cols];
        }

        // Replaces the whole valid-cell set at once rather than incremental per-tile updates, since which
        // cells are valid can change completely between episodes (spawn-distance curriculum, agent
        // positions) rather than only ever growing like WasSeenLayer's seen set.
        public void SetValidCells(IEnumerable<(int row, int col)> validCells)
        {
            System.Array.Clear(_tilesData, 0, _tilesData.Length);
            foreach (var (row, col) in validCells)
                _tilesData[row, col] = true;
            RefreshLayer();
        }

        public void UpdateLayer() { }

        public void RefreshLayer()
        {
            for (int row = 0; row < _tilesData.GetLength(0); row++)
            {
                for (int col = 0; col < _tilesData.GetLength(1); col++)
                {
                    Color colour = _tilesData[row, col] ? InfluenceMap.HighlightedColour : InfluenceMap.BaseColour;
                    _influenceMap?.SetTileColour(col, row, colour, LayerType);
                }
            }
        }
    }
}
