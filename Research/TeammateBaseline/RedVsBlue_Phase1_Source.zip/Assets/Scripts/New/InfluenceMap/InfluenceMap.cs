using UnityEngine;
using System.Collections.Generic;

namespace RedVsBlue
{
    public class InfluenceMap : MonoBehaviour
    {
        public enum LayerTag
        {
            WasSeen,
            TimeSinceLastSeen,
            DistanceToGoal,
            AgentPositions,
            RedSpawn,
            RedSpawnProbability,

            // Visualisation off: every tile stays BaseColour. No layer carries this tag, so every
            // SetTileColour call hits the "not the current layer" early-out and nothing repaints --
            // the layers still compute their data, they just stop painting.
            //
            // MUST stay last. The selection is serialized by enum index (_inspectorSelectedLayer),
            // so inserting a value anywhere earlier would silently repoint every existing prefab's
            // saved choice at a different layer.
            None
        }

        [SerializeField] private LayerTag _inspectorSelectedLayer = LayerTag.TimeSinceLastSeen;
        private LayerTag _currLayer = LayerTag.TimeSinceLastSeen;
        private GridManager _grid;
        private Renderer[,] _tilesData;
        private MaterialPropertyBlock _tilePropertyBlock;
        private int _rows;
        private int _cols;
        private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
        private static readonly int ColorId = Shader.PropertyToID("_Color");
        public static readonly Color HighlightedColour = Color.red;
        public static readonly Color BaseColour = Color.white;
        public static readonly Color SecondaryColour = Color.green;

        // Layers storage
        private WasSeenLayer _wasSeenLayer;
        private TimeSinceLastSeenLayer _timeSinceLastSeenLayer;
        private DistanceToGoalLayer _distanceToGoalLayer;
        private AgentPositionsLayer _agentPositionsLayer;
        private RedSpawnLayer _redSpawnLayer;
        private RedSpawnProbabilityLayer _redSpawnProbabilityLayer;


        // Getters and Setters
        public LayerTag CurrentLayer
        {
            get => _currLayer;
            set
            {
                if (_currLayer != value)
                {
                    _currLayer = value;
                    _inspectorSelectedLayer = value;
                    RefreshCurrentLayer();
                }
            }
        }

        // The GridManager is the authority on both grid dimensions and walkability; the tile Renderers
        // it built are pulled in here purely as a painting surface (null wherever there's a wall).
        public void Initialise(GridManager grid)
        {
            // Initialise grid data
            _grid = grid;
            _rows = grid.Rows;
            _cols = grid.Cols;
            _tilesData = new Renderer[_rows, _cols];

            // _currLayer isn't serialized (no [SerializeField]) but _inspectorSelectedLayer is, so
            // after a load the two disagree until the first UpdateLayers() reconciles them. Until
            // then every SetTileColour for the inspector's chosen layer hits the "not the current
            // layer" early-out and paints nothing -- which silently swallows any data pushed during
            // episode setup. Sync up front instead.
            _currLayer = _inspectorSelectedLayer;

            for (int row = 0; row < _rows; row++)
                for (int col = 0; col < _cols; col++)
                    _tilesData[row, col] = grid.GetTileRenderer(row, col);

            InitialiseLayers();
        }

        public void ResetLayers()
        {
            InitialiseLayers();
            RefreshCurrentLayer();
        }

        private void InitialiseLayers()
        {
            // The array initialiser is load-bearing: each element assigns its layer field before the
            // foreach runs, so a layer's Initialise can cache its sibling layers via GetLayer(...)
            // (see TimeSinceLastSeenLayer.Initialise) and find them non-null.
            IInfluenceLayer[] layers = new IInfluenceLayer[]
            {
                _wasSeenLayer = new WasSeenLayer(),
                _timeSinceLastSeenLayer = new TimeSinceLastSeenLayer(),
                _distanceToGoalLayer = new DistanceToGoalLayer(),
                _agentPositionsLayer = new AgentPositionsLayer(),
                _redSpawnLayer = new RedSpawnLayer(),
                _redSpawnProbabilityLayer = new RedSpawnProbabilityLayer()
            };

            foreach (var layer in layers)
            {
                layer.Initialise(_rows, _cols, this);
            }
        }

        public IInfluenceLayer GetLayer(LayerTag layerTag)
        {
            return layerTag switch
            {
                LayerTag.WasSeen => _wasSeenLayer,
                LayerTag.TimeSinceLastSeen => _timeSinceLastSeenLayer,
                LayerTag.DistanceToGoal => _distanceToGoalLayer,
                LayerTag.AgentPositions => _agentPositionsLayer,
                LayerTag.RedSpawn => _redSpawnLayer,
                LayerTag.RedSpawnProbability => _redSpawnProbabilityLayer,
                _ => null
            };
        }

        // Internal painting helper only -- a null Renderer means "nothing to tint here". Never use this
        // to ask whether a cell is a wall; ask IsWalkable instead.
        private Renderer GetTile(int row, int col)
        {
            return IsInBounds(row, col) ? _tilesData[row, col] : null;
        }

        // Walkability is the grid's answer, not the renderer's. Exposed publicly because layers
        // (TimeSinceLastSeenLayer's LOS raycast) need it.
        public bool IsWalkable(int row, int col) => _grid != null && _grid.IsWalkable(row, col);

        // Note the argument order: (col, row) here, but GetTile takes (row, col). Kept as-is so the
        // layer bodies calling SetTileColour(col, row, ...) stay unchanged.
        public void SetTileColour(int col, int row, Color colour, LayerTag layerTag)
        {
            // Check if current layer matches the layerTag, if not, do not set the colour
            if (layerTag != _currLayer) return;

            // Check if tile is valid (in bounds)
            Renderer tile = GetTile(row, col);
            if (tile == null) return;

            // Set per-tile colour without duplicating the shared material.
            _tilePropertyBlock ??= new MaterialPropertyBlock();
            _tilePropertyBlock.Clear();
            tile.GetPropertyBlock(_tilePropertyBlock);
            _tilePropertyBlock.SetColor(BaseColorId, colour);
            _tilePropertyBlock.SetColor(ColorId, colour);
            tile.SetPropertyBlock(_tilePropertyBlock);
        }

        public void SetDistanceToGoalData(float[,] distances)
        {
            _distanceToGoalLayer?.SetData(distances);
        }

        public void SetRedSpawnCandidates(IEnumerable<(int row, int col)> validCells)
        {
            _redSpawnLayer?.SetValidCells(validCells);
        }

        public void SetRedSpawnProbabilities(Dictionary<(int row, int col), float> cellWeights)
        {
            _redSpawnProbabilityLayer?.SetSpawnProbabilities(cellWeights);
        }

        private void RefreshCurrentLayer()
        {
            switch (_currLayer)
            {
                case LayerTag.WasSeen:
                    _wasSeenLayer?.RefreshLayer();
                    break;
                case LayerTag.TimeSinceLastSeen:
                    _timeSinceLastSeenLayer?.RefreshLayer();
                    break;
                case LayerTag.DistanceToGoal:
                    _distanceToGoalLayer?.RefreshLayer();
                    break;
                case LayerTag.AgentPositions:
                    _agentPositionsLayer?.RefreshLayer();
                    break;
                case LayerTag.RedSpawn:
                    _redSpawnLayer?.RefreshLayer();
                    break;
                case LayerTag.RedSpawnProbability:
                    _redSpawnProbabilityLayer?.RefreshLayer();
                    break;
                case LayerTag.None:
                    // Wipe back to plain white once, so whatever the previously selected layer had
                    // painted doesn't linger. Passing LayerTag.None is what gets these through
                    // SetTileColour's early-out, since it matches _currLayer here.
                    for (int row = 0; row < _rows; row++)
                        for (int col = 0; col < _cols; col++)
                            SetTileColour(col, row, BaseColour, LayerTag.None);
                    break;
            }
        }

        private bool IsInBounds(int row, int col)
        {
            return _tilesData != null
                && row >= 0 && row < _rows
                && col >= 0 && col < _cols;
        }

        public void UpdateAgentPosition(Vector2Int agentTilePos, int agentId)
        {
            _agentPositionsLayer?.SetData(agentTilePos, agentId);
        }

        public bool WasTileSeen(int row, int col) => _wasSeenLayer?.GetData(row, col) ?? false;

        public int GetSeenCount() => _wasSeenLayer?.GetSeenCount() ?? 0;

        // Agent will call this function to update layers that need to be updated based on the agent's observations
        public (int totalObservedCount, int totalNewlyObservedCount, HashSet<int> observedAgentsInFOV) UpdateAgentObservations(Vector2Int agentTilePos, float bearing, int agentId)
        {
            return _timeSinceLastSeenLayer?.UpdateLOS(agentTilePos, 30, bearing - 60f, bearing + 60f, agentId) ?? (0, 0, new HashSet<int>());
        }

        // Call each layer's UpdateLayer, needs to be done regardless of current layer
        // Some layers' UpdateLayer may not do anything
        public void UpdateLayers()
        {
            if (_inspectorSelectedLayer != _currLayer)
                CurrentLayer = _inspectorSelectedLayer;

            _timeSinceLastSeenLayer?.UpdateLayer();
        }
    }
}
