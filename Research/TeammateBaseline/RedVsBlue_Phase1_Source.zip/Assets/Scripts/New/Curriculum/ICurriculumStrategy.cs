using System.Collections.Generic;

namespace RedVsBlue
{
    // Decides which map and which agent/hider spawn locations a training area should run next,
    // given how its episodes have been going. This is the only place training progression logic
    // lives -- swapping the strategy swaps the entire curriculum without touching training area
    // code.
    //
    // Two-step by design, so an area only pays for what actually changed:
    //
    //   1. ReportResults(results) -- the area hands in its outcome. The return value says whether
    //      that changes what should run next. A static curriculum (same map, same spawns forever)
    //      always answers false, and the area simply re-runs its stored EpisodeConstructionData
    //      with no allocation.
    //   2. TryGetNextEpisode(...) -- called only when step 1 answered true, or once at startup to
    //      seed the first episode. Returns false when the simulation is finished and no further
    //      episodes should run.
    //
    // ReportResults is where a strategy ACCUMULATES outcomes (streak counters, success windows,
    // per-map catch tallies). TryGetNextEpisode takes the triggering result too, but only as
    // optional read-only context, so a strategy that wants it can let that outcome directly shape
    // the next episode ("they cleared it -- jump straight to the next map"). Being optional also
    // keeps the startup call clean, where there is no previous episode to describe.
    //
    // Never accumulate in TryGetNextEpisode: the same episode reaches both calls, so counting in
    // both double-counts it.
    public interface ICurriculumStrategy
    {
        // True = what should run next has changed; the caller must fetch fresh data via
        // TryGetNextEpisode. False = nothing changed; reuse the previous EpisodeConstructionData.
        bool ReportResults(EpisodeResults results);

        // False = simulation finished, stop running episodes.
        bool TryGetNextEpisode(IReadOnlyList<Map> maps, out EpisodeConstructionData next, EpisodeResults results = default);
    }
}
