using UnityEngine;

namespace RedVsBlue
{
    // Outcome of one finished episode in one training area, handed back to the curriculum so a
    // strategy can decide what that area should run next.
    //
    // mapIndex is the same id the curriculum stamped on the EpisodeConstructionData that produced
    // this episode, so a result can be attributed to the map it came from. Without it a strategy
    // can't keep per-map state -- the old CurriculumManager's redCatchCounts were global, which its
    // own comment flagged as a bug once map switching was enabled.
    //
    // OPEN: this field set is still provisional. Add fields as strategies demand them rather than
    // guessing up front -- plausible future ones include per-agent contribution,
    // time-to-first-catch, or coverage achieved.
    public struct EpisodeResults
    {
        public int mapIndex;

        // Which training area produced this. Advancement decisions pool across areas (they all run
        // one shared policy, so areas are parallel samples of the same learner rather than
        // independent ones), but per-area attribution is needed for diagnosis, and for any strategy
        // that chooses to run each area at its own difficulty.
        public int areaId;

        public bool allHidersCaught;
        public int hidersCaught;
        public int steps;
        public float groupReward;

        // Grid cell each hider was standing on when caught, in the order they were caught. Feeds the
        // inverse catch-count spawn weighting: cells that keep yielding catches become progressively
        // less likely to be picked again. Null or empty when nothing was caught.
        public Vector2Int[] hiderCaughtCells;
    }
}
