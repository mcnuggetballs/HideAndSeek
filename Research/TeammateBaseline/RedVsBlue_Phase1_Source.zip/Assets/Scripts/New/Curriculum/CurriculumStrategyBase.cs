using System.Collections.Generic;
using UnityEngine;

namespace RedVsBlue
{
    // Shared mechanics for curriculum strategies. Exists as an abstract class rather than living on
    // ICurriculumStrategy because an interface can't carry implementation, and these are real shared
    // behaviours rather than part of the contract a training area depends on.
    //
    // Only strategy-side concerns belong here. Pure grid questions ("which cells are 10-11 steps
    // from blue?") live on Map, next to its other walking-distance query -- a strategy asks the map,
    // it doesn't own the graph search.
    public abstract class CurriculumStrategyBase : ICurriculumStrategy
    {
        public abstract bool ReportResults(EpisodeResults results);

        public abstract bool TryGetNextEpisode(IReadOnlyList<Map> maps, out EpisodeConstructionData next, EpisodeResults results = default);

        // Where blue is allowed to start: the map's dedicated 'B' cells when it defines any, else
        // anywhere walkable. Virtual because this IS a curriculum decision -- a strategy that wants
        // blue pinned to fixed cells, or clustered, or fully random, overrides it.
        protected virtual Vector2Int[] PickAgentCells(Map map, int count)
        {
            List<Vector2Int> pool = new(map.AgentSpawnCells.Count > 0 ? map.AgentSpawnCells : map.WalkableCells);
            return DrawUniform(pool, count);
        }

        // Shuffles in place and takes the first `count` -- sampling without replacement, so two
        // agents never share a cell unless the pool is smaller than the number needed.
        protected static Vector2Int[] DrawUniform(List<Vector2Int> pool, int count)
        {
            for (int i = pool.Count - 1; i > 0; i--)
            {
                int j = Random.Range(0, i + 1);
                (pool[i], pool[j]) = (pool[j], pool[i]);
            }

            Vector2Int[] cells = new Vector2Int[count];
            for (int i = 0; i < count; i++)
                cells[i] = pool[i % pool.Count];
            return cells;
        }

        // Cumulative-weight sampling without replacement. Copies the pool rather than reordering it,
        // so the caller's pool stays index-aligned with its weight array -- which matters because
        // that same pairing is handed to the influence map for display. Pools are a few hundred cells
        // at most and this runs once per episode, so an O(n) scan per draw is plenty.
        protected static Vector2Int[] DrawWeighted(IReadOnlyList<Vector2Int> pool, IReadOnlyList<float> weights, int count)
        {
            List<Vector2Int> remaining = new(pool);
            List<float> remainingWeights = new(weights);
            Vector2Int[] cells = new Vector2Int[count];

            for (int i = 0; i < count; i++)
            {
                // Fewer distinct cells than agents needed -- refill so the draw can wrap.
                if (remaining.Count == 0)
                {
                    remaining = new List<Vector2Int>(pool);
                    remainingWeights = new List<float>(weights);
                }

                float total = 0f;
                foreach (float weight in remainingWeights) total += weight;

                int picked;
                if (total > 0f)
                {
                    float roll = Random.Range(0f, total);
                    float cumulative = 0f;
                    picked = remaining.Count - 1; // float-rounding fallback
                    for (int j = 0; j < remaining.Count; j++)
                    {
                        cumulative += remainingWeights[j];
                        if (roll <= cumulative) { picked = j; break; }
                    }
                }
                else picked = Random.Range(0, remaining.Count);

                cells[i] = remaining[picked];
                remaining.RemoveAt(picked);
                remainingWeights.RemoveAt(picked);
            }

            return cells;
        }
    }
}
