using UnityEngine;

namespace RedVsBlue
{
    // Everything a training area needs to build and run one episode. Produced by the curriculum,
    // consumed by TrainingAreaManager.Load. Locations are grid coordinates -- Vector2Int(x = col,
    // y = row) -- which the area converts to world positions via its own GridManager, so the
    // curriculum never needs to know an area's world placement.
    public struct EpisodeConstructionData
    {
        public int mapIndex;
        public Vector2Int[] agentLocations;
        public Vector2Int[] hiderLocations;

        // Visualisation only -- the full pool the hider locations were drawn from, and each cell's
        // relative draw weight (same indexing). Carried here because the strategy is what computes
        // the pool, and it deliberately holds no InfluenceMap reference; without this the RedSpawn /
        // RedSpawnProbability layers have no data source and render as a blank white grid.
        //
        // Both may be null: a strategy that doesn't sample from a pool simply leaves them unset, and
        // EpisodeManager skips the push.
        public Vector2Int[] hiderCandidates;
        public float[] hiderCandidateWeights;
    }
}
