using System.Collections.Generic;
using UnityEngine;

namespace RedVsBlue
{
    // Simplest usable curriculum, and the baseline to debug against: one fixed map, a fixed distance
    // band, no progression. Blue goes on the map's 'B' spawn cells; hiders are drawn uniformly from
    // the cells whose shortest WALKING distance to the nearest blue agent falls inside
    // [minDistance, maxDistance] -- close enough to be reachable, far enough not to start in plain
    // sight.
    //
    // rerandomiseSpawns drives the ReportResults contract. When false the episode is picked once and
    // never changes, so ReportResults answers false and every area re-runs its stored
    // EpisodeConstructionData with no further allocation (the "static curriculum" case). When true,
    // spawn locations are redrawn each episode.
    //
    // For the real progressing curriculum see SpawnCurriculumStrategy.
    public class FixedCurriculumStrategy : CurriculumStrategyBase
    {
        private readonly int _mapIndex;
        private readonly int _agentCount;
        private readonly int _hiderCount;
        private readonly int _minDistance;
        private readonly int _maxDistance;
        private readonly bool _rerandomiseSpawns;

        public FixedCurriculumStrategy(
            int mapIndex,
            int agentCount,
            int hiderCount,
            int minDistance,
            int maxDistance,
            bool rerandomiseSpawns = true)
        {
            _mapIndex = mapIndex;
            _agentCount = agentCount;
            _hiderCount = hiderCount;
            _minDistance = minDistance;
            _maxDistance = maxDistance;
            _rerandomiseSpawns = rerandomiseSpawns;
        }

        // Nothing is accumulated here -- this strategy has no progression state. The answer is purely
        // "will the next episode differ from the last one".
        public override bool ReportResults(EpisodeResults results) => _rerandomiseSpawns;

        public override bool TryGetNextEpisode(IReadOnlyList<Map> maps, out EpisodeConstructionData next, EpisodeResults results = default)
        {
            next = default;
            if (maps == null || _mapIndex < 0 || _mapIndex >= maps.Count)
            {
                Debug.LogError($"[FixedCurriculumStrategy] mapIndex {_mapIndex} is out of range.");
                return false;
            }

            Map map = maps[_mapIndex];
            if (map == null || map.WalkableCells.Count == 0)
            {
                Debug.LogError("[FixedCurriculumStrategy] Map has no walkable cells.");
                return false;
            }

            Vector2Int[] agents = PickAgentCells(map, _agentCount);
            List<Vector2Int> band = map.ComputeDistanceBand(agents, _minDistance, _maxDistance);

            if (band.Count == 0)
            {
                Debug.LogWarning(
                    $"[FixedCurriculumStrategy] No cells within [{_minDistance}, {_maxDistance}] of blue on " +
                    $"'{map.Name}' -- falling back to any walkable cell.");
                band = new List<Vector2Int>(map.WalkableCells);
            }

            // Uniform sampling, so every candidate carries the same weight. The probability layer
            // normalises against the pool maximum, so a uniform pool reads as solid red across the
            // whole band -- exactly what "all equally likely" should look like.
            float[] weights = new float[band.Count];
            for (int i = 0; i < weights.Length; i++) weights[i] = 1f;

            next = new EpisodeConstructionData
            {
                mapIndex = _mapIndex,
                agentLocations = agents,
                // DrawWeighted copies its pool, so `band` stays index-aligned with `weights` --
                // which is what lets the influence map render the true weighting.
                hiderLocations = DrawWeighted(band, weights, _hiderCount),
                hiderCandidates = band.ToArray(),
                hiderCandidateWeights = weights,
            };
            return true;
        }
    }
}
