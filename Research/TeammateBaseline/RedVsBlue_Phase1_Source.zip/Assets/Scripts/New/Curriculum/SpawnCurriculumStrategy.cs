using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace RedVsBlue
{
    // Reproduces the Cortex training curriculum, which shapes WHERE hiders spawn along two axes:
    //
    //   1. Distance. Hiders start close to blue and the allowed band widens by distanceIncrement
    //      each time the team proves it can clear the current one.
    //   2. Location. Cells where hiders keep getting caught become progressively less likely to be
    //      picked, so the team stops re-solving the same few spots.
    //
    // Advancement is a POOLED rolling window, not a per-area streak. Every area runs the same
    // behaviour name, so all areas share ONE policy -- they're parallel samples of the same learner,
    // not independent ones. "Any area got 10 in a row" would advance on the luckiest sample and get
    // easier the more areas you add; pooling the last N outcomes measures the same policy with N
    // times the data and far less variance. A window also degrades gracefully where a strict streak
    // is brittle: one unlucky episode slides out rather than wiping nine good ones.
    //
    // Map unlocking is deliberately not implemented -- one fixed map. Nothing here blocks it later:
    // EpisodeConstructionData already carries mapIndex outward and EpisodeResults carries it back.
    public class SpawnCurriculumStrategy : CurriculumStrategyBase
    {
        private readonly int _mapIndex;
        private readonly int _agentCount;
        private readonly int _hiderCount;
        private readonly int _minDistance;
        private readonly int _startMaxDistance;
        private readonly int _distanceIncrement;
        private readonly int _windowSize;
        private readonly float _successThreshold;
        private readonly string _savePath;

        private State _state;

        // Runtime index over State.catchCounts so a lookup isn't a linear scan of a list that grows
        // for the whole run. Rebuilt on load, points at the same objects the list holds.
        private readonly Dictionary<(int map, int row, int col), CatchCount> _catchIndex = new();

        [Serializable]
        private class CatchCount
        {
            public int mapIndex;
            public int row;
            public int col;
            public int count;
        }

        [Serializable]
        private class State
        {
            public int maxDistance = -1;         // -1 = "not seeded yet", filled from startMaxDistance
            public List<int> window = new();     // 1 = every hider caught, 0 = not. Pooled across areas.
            public List<CatchCount> catchCounts = new();
            public int advanceCount;             // diagnostics only
        }

        public SpawnCurriculumStrategy(
            int mapIndex,
            int agentCount,
            int hiderCount,
            int minDistance,
            int startMaxDistance,
            int distanceIncrement,
            int windowSize,
            float successThreshold,
            string savePath)
        {
            _mapIndex = mapIndex;
            _agentCount = agentCount;
            _hiderCount = hiderCount;
            _minDistance = minDistance;
            _startMaxDistance = startMaxDistance;
            _distanceIncrement = Mathf.Max(1, distanceIncrement);
            _windowSize = Mathf.Max(1, windowSize);
            _successThreshold = successThreshold;
            _savePath = savePath;

            Load();
        }

        public int MaxDistance => _state.maxDistance;

        public override bool ReportResults(EpisodeResults results)
        {
            RecordCatches(results);

            _state.window.Add(results.allHidersCaught ? 1 : 0);
            while (_state.window.Count > _windowSize) _state.window.RemoveAt(0);

            if (_state.window.Count >= _windowSize)
            {
                int successes = 0;
                foreach (int outcome in _state.window) successes += outcome;
                float rate = (float)successes / _state.window.Count;

                if (rate >= _successThreshold)
                {
                    _state.maxDistance += _distanceIncrement;
                    _state.advanceCount++;
                    // Cleared, not slid: the new difficulty has to earn a full window of fresh
                    // evidence, otherwise the old window's successes would immediately part-qualify
                    // the next advance too.
                    _state.window.Clear();
                    Debug.Log($"[Curriculum] Hider max distance -> {_state.maxDistance} " +
                              $"(advance #{_state.advanceCount}, {rate:P0} over {_windowSize} pooled episodes)");
                }
            }

            Save();

            // Hider cells are redrawn every episode, so what runs next always differs.
            return true;
        }

        public override bool TryGetNextEpisode(IReadOnlyList<Map> maps, out EpisodeConstructionData next, EpisodeResults results = default)
        {
            next = default;
            if (maps == null || _mapIndex < 0 || _mapIndex >= maps.Count)
            {
                Debug.LogError($"[SpawnCurriculumStrategy] mapIndex {_mapIndex} is out of range.");
                return false;
            }

            Map map = maps[_mapIndex];
            if (map == null || map.WalkableCells.Count == 0)
            {
                Debug.LogError("[SpawnCurriculumStrategy] Map has no walkable cells.");
                return false;
            }

            Vector2Int[] agents = PickAgentCells(map, _agentCount);
            List<Vector2Int> band = map.ComputeDistanceBand(agents, _minDistance, _state.maxDistance);

            if (band.Count == 0)
            {
                Debug.LogWarning(
                    $"[SpawnCurriculumStrategy] No cells within [{_minDistance}, {_state.maxDistance}] of blue on " +
                    $"'{map.Name}' -- falling back to any walkable cell.");
                band = new List<Vector2Int>(map.WalkableCells);
            }

            // Inverse catch-count weighting: a cell that keeps yielding catches gets progressively
            // less likely to be drawn, but 1/(1+count) never reaches zero, so a well-solved cell is
            // discouraged rather than permanently excluded.
            float[] weights = new float[band.Count];
            for (int i = 0; i < band.Count; i++)
                weights[i] = 1f / (1f + CatchCountAt(_mapIndex, band[i]));

            next = new EpisodeConstructionData
            {
                mapIndex = _mapIndex,
                agentLocations = agents,
                hiderLocations = DrawWeighted(band, weights, _hiderCount),
                // DrawWeighted copies its pool, so `band` is still index-aligned with `weights` --
                // which is what lets RedSpawnProbability render the true weighting.
                hiderCandidates = band.ToArray(),
                hiderCandidateWeights = weights,
            };
            return true;
        }

        // Keyed by map as well as cell. The original tracked catches globally, and its own comment
        // flagged that as a bug the moment more than one map was in play.
        private void RecordCatches(EpisodeResults results)
        {
            if (results.hiderCaughtCells == null) return;

            foreach (Vector2Int cell in results.hiderCaughtCells)
            {
                var key = (results.mapIndex, cell.y, cell.x);
                if (!_catchIndex.TryGetValue(key, out CatchCount entry))
                {
                    entry = new CatchCount { mapIndex = results.mapIndex, row = cell.y, col = cell.x };
                    _state.catchCounts.Add(entry);
                    _catchIndex[key] = entry;
                }
                entry.count++;
            }
        }

        private int CatchCountAt(int mapIndex, Vector2Int cell) =>
            _catchIndex.TryGetValue((mapIndex, cell.y, cell.x), out CatchCount entry) ? entry.count : 0;

        private void Load()
        {
            _state = null;
            try
            {
                if (File.Exists(_savePath))
                    _state = JsonUtility.FromJson<State>(File.ReadAllText(_savePath));
            }
            catch (Exception e)
            {
                // A corrupt or half-written progress file must not stop training -- start fresh.
                Debug.LogWarning($"[Curriculum] Could not read '{_savePath}': {e.Message}. Starting fresh.");
            }

            _state ??= new State();
            _state.window ??= new List<int>();
            _state.catchCounts ??= new List<CatchCount>();
            if (_state.maxDistance < 0) _state.maxDistance = _startMaxDistance;

            _catchIndex.Clear();
            foreach (CatchCount entry in _state.catchCounts)
                _catchIndex[(entry.mapIndex, entry.row, entry.col)] = entry;

            Debug.Log($"[Curriculum] Loaded: maxDistance {_state.maxDistance}, " +
                      $"{_state.window.Count}/{_windowSize} in window, {_state.catchCounts.Count} tracked cells.");
        }

        // Written after every reported episode, matching the original's behaviour. The file is small
        // (a window plus one entry per caught-on cell), so the per-episode write is cheap -- but note
        // it is synchronous, and every area reports independently.
        private void Save()
        {
            try
            {
                File.WriteAllText(_savePath, JsonUtility.ToJson(_state, true));
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[Curriculum] Could not write '{_savePath}': {e.Message}");
            }
        }
    }
}
