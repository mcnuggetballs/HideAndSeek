using System.Collections.Generic;

namespace RedVsBlue
{
    // Signatures of the two delegates a TrainingAreaManager holds. TryGetNextEpisode needs its own
    // delegate type because an out parameter can't be expressed with Func<>.
    public delegate bool ReportResultsDelegate(EpisodeResults results);
    public delegate bool TryGetNextEpisodeDelegate(out EpisodeConstructionData next, EpisodeResults results = default);

    // Oversees training across every training area: owns the shared map list and the strategy that
    // decides what each area runs next.
    //
    // Areas never hold a reference to this object -- SimulationManager hands each one delegates
    // pointing at ReportResults and TryGetNextEpisode, so an area only knows "report my result,
    // get my next episode" and stays independently testable.
    public class Curriculum
    {
        private readonly List<Map> _maps;
        private readonly ICurriculumStrategy _strategy;

        public Curriculum(IEnumerable<Map> maps, ICurriculumStrategy strategy)
        {
            _maps = new List<Map>(maps);
            _strategy = strategy;
        }

        public IReadOnlyList<Map> Maps => _maps;
        public Map GetMap(int index) => index >= 0 && index < _maps.Count ? _maps[index] : null;

        public bool ReportResults(EpisodeResults results) => _strategy.ReportResults(results);

        public bool TryGetNextEpisode(out EpisodeConstructionData next, EpisodeResults results = default) =>
            _strategy.TryGetNextEpisode(_maps, out next, results);
    }
}
