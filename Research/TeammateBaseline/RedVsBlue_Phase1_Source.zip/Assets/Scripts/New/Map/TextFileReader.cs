using UnityEngine;

namespace RedVsBlue
{
    // Parses a grid TextAsset into a raw 2D character array, trimming leading/trailing blank lines.
    // Purely textual -- callers interpret cell characters (walls, spawn points, etc.) themselves.
    public static class TextFileReader
    {
        public static char[,] ReadGrid(TextAsset textFile)
        {
            if (textFile == null)
            {
                Debug.LogWarning("[TextFileReader] No text file assigned.");
                return null;
            }

            string[] allLines = textFile.text.Split('\n');

            int firstNonEmpty = 0;
            int lastNonEmpty = allLines.Length - 1;

            while (firstNonEmpty <= lastNonEmpty && allLines[firstNonEmpty].Trim() == "")
                firstNonEmpty++;
            while (lastNonEmpty >= firstNonEmpty && allLines[lastNonEmpty].Trim() == "")
                lastNonEmpty--;

            if (firstNonEmpty > lastNonEmpty)
            {
                Debug.LogWarning($"[TextFileReader] '{textFile.name}' is empty.");
                return null;
            }

            int rows = lastNonEmpty - firstNonEmpty + 1;
            int cols = 0;
            for (int i = firstNonEmpty; i <= lastNonEmpty; i++)
            {
                int len = allLines[i].TrimEnd().Length;
                if (len > cols) cols = len;
            }

            // Short lines are padded with spaces rather than left ragged, so every row is exactly
            // `cols` wide and callers can index [r, c] without a per-line length check.
            char[,] grid = new char[rows, cols];
            for (int r = 0; r < rows; r++)
            {
                string line = allLines[firstNonEmpty + r].TrimEnd();
                for (int c = 0; c < cols; c++)
                    grid[r, c] = c < line.Length ? line[c] : ' ';
            }

            return grid;
        }
    }
}
