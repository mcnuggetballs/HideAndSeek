using System.Collections.Generic;
using UnityEngine;

namespace RedVsBlue
{
    // Immutable parsed grid map. Built once per TextAsset by SimulationManager and shared by
    // reference across every training area -- nothing mutates it after construction, so sharing is
    // safe and avoids N copies of the same walkability grid.
    //
    // Grid coordinates are Vector2Int(x = col, y = row) to match the WorldToGrid convention used
    // throughout the project; the raw arrays stay [row, col].
    public class Map
    {
        public const char WallChar = 'X';
        public const char AgentSpawnChar = 'B';

        public string Name { get; }
        public int Rows { get; }
        public int Cols { get; }

        private readonly bool[,] _walkable;
        private readonly List<Vector2Int> _walkableCells = new();
        private readonly List<Vector2Int> _agentSpawnCells = new();

        public IReadOnlyList<Vector2Int> WalkableCells => _walkableCells;
        public IReadOnlyList<Vector2Int> AgentSpawnCells => _agentSpawnCells;

        public Map(TextAsset textFile)
        {
            Name = textFile != null ? textFile.name : "<none>";

            char[,] grid = TextFileReader.ReadGrid(textFile);
            if (grid == null)
            {
                _walkable = new bool[0, 0];
                return;
            }

            Rows = grid.GetLength(0);
            Cols = grid.GetLength(1);
            _walkable = new bool[Rows, Cols];

            for (int row = 0; row < Rows; row++)
            {
                for (int col = 0; col < Cols; col++)
                {
                    char cell = grid[row, col];
                    if (cell == WallChar) continue;

                    _walkable[row, col] = true;
                    _walkableCells.Add(new Vector2Int(col, row));
                    if (cell == AgentSpawnChar) _agentSpawnCells.Add(new Vector2Int(col, row));
                }
            }
        }

        public bool IsInBounds(int row, int col) => row >= 0 && row < Rows && col >= 0 && col < Cols;
        public bool IsWalkable(int row, int col) => IsInBounds(row, col) && _walkable[row, col];
        public bool IsWalkable(Vector2Int gridPos) => IsWalkable(gridPos.y, gridPos.x);

        // Every walkable cell whose shortest WALKING distance to the nearest `from` cell falls inside
        // [minDistance, maxDistance]. One multi-source BFS out from all sources at once (walls
        // blocking traversal) rather than a fresh search per candidate, capped at maxDistance so cost
        // is bounded by the band rather than by map size.
        //
        // Walking distance, not straight line, so a cell just the other side of a wall is correctly
        // treated as far away. Same reasoning as AreTilesWithinHops, but 4-directional and
        // multi-source: this answers "how far is every cell from the nearest agent".
        public List<Vector2Int> ComputeDistanceBand(IReadOnlyList<Vector2Int> from, int minDistance, int maxDistance)
        {
            List<Vector2Int> band = new();
            HashSet<Vector2Int> visited = new();
            Queue<(Vector2Int cell, int depth)> frontier = new();

            foreach (Vector2Int cell in from)
            {
                if (!visited.Add(cell)) continue;
                frontier.Enqueue((cell, 0));
                if (minDistance <= 0) band.Add(cell);
            }

            Vector2Int[] neighbours = { new(-1, 0), new(1, 0), new(0, -1), new(0, 1) };

            while (frontier.Count > 0)
            {
                (Vector2Int cell, int depth) = frontier.Dequeue();
                if (depth >= maxDistance) continue;

                foreach (Vector2Int offset in neighbours)
                {
                    Vector2Int next = cell + offset;
                    if (!IsWalkable(next)) continue;
                    if (!visited.Add(next)) continue;

                    int nextDepth = depth + 1;
                    if (nextDepth >= minDistance) band.Add(next);
                    frontier.Enqueue((next, nextDepth));
                }
            }

            return band;
        }

        private const float DiagonalStepCost = 1.41421356f; // sqrt(2)

        // Dijkstra out from `from` (walls blocking traversal, diagonal steps allowed but weighted
        // sqrt(2) and forbidden from cutting a wall corner) up to maxHops, early-exiting the instant
        // `to` is reached -- a real walking-path check rather than straight-line distance, so two
        // agents standing next to each other but on opposite sides of a wall are correctly "far
        // apart". 8-directional with diagonal weighting rather than plain 4-directional hop counting,
        // since the latter measures Manhattan distance and badly overestimates (up to ~41% at a pure
        // 45-degree offset) how far apart two diagonally-placed agents actually are in this
        // continuous-movement game. Uses a linear-scan "pick smallest" instead of a real priority
        // queue since the search is small and tightly bounded by maxHops.
        public bool AreTilesWithinHops(Vector2Int from, Vector2Int to, int maxHops)
        {
            if (from == to) return true;

            var bestDist = new Dictionary<Vector2Int, float> { [from] = 0f };
            var frontier = new List<(Vector2Int cell, float dist)> { (from, 0f) };

            (int dCol, int dRow, float cost)[] neighbours =
            {
                (0, -1, 1f), (0, 1, 1f), (-1, 0, 1f), (1, 0, 1f),
                (-1, -1, DiagonalStepCost), (1, -1, DiagonalStepCost),
                (-1, 1, DiagonalStepCost), (1, 1, DiagonalStepCost),
            };

            while (frontier.Count > 0)
            {
                int bestIndex = 0;
                for (int i = 1; i < frontier.Count; i++)
                    if (frontier[i].dist < frontier[bestIndex].dist) bestIndex = i;

                (Vector2Int cell, float dist) = frontier[bestIndex];
                frontier.RemoveAt(bestIndex);

                foreach (var (dCol, dRow, cost) in neighbours)
                {
                    Vector2Int next = new(cell.x + dCol, cell.y + dRow);
                    if (!IsWalkable(next)) continue;

                    // Don't allow cutting a diagonal move through a wall corner -- both cardinal
                    // cells adjacent to the step must also be walkable.
                    if (dCol != 0 && dRow != 0 &&
                        (!IsWalkable(cell.y + dRow, cell.x) || !IsWalkable(cell.y, cell.x + dCol))) continue;

                    float nextDist = dist + cost;
                    if (nextDist > maxHops) continue;
                    if (bestDist.TryGetValue(next, out float existing) && existing <= nextDist) continue;

                    bestDist[next] = nextDist;
                    if (next == to) return true;
                    frontier.Add((next, nextDist));
                }
            }

            return false;
        }
    }
}
