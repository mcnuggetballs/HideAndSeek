using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace RedVsBlue
{
    // Top of the scene, and the only object that knows the whole system. Builds the shared Map list
    // and the single Curriculum, spawns the training areas, wires each area's curriculum delegates,
    // then seeds and starts its first episode.
    //
    // Order matters: the Curriculum must exist before any area does, since an area is handed its
    // delegates the moment it spawns.
    public class SimulationManager : MonoBehaviour
    {
        [Header("Maps")]
        [Tooltip("Grid text assets, in curriculum order. Index here is the mapIndex used throughout.")]
        [SerializeField] private TextAsset[] mapFiles;

        [Header("Areas")]
        [SerializeField] private TrainingAreaSpawner spawner;

        public enum StrategyMode
        {
            Progressing, // SpawnCurriculumStrategy -- distance advances, catch-weighted spawns
            Fixed,       // FixedCurriculumStrategy -- fixed distance band, no progression
            Random,      // FixedCurriculumStrategy with the band opened up -- hiders anywhere
        }

        [Header("Curriculum")]
        [SerializeField] private StrategyMode strategy = StrategyMode.Progressing;
        [SerializeField] private int fixedMapIndex = 0;
        [SerializeField] private int numberOfBlueAgents = 2;
        [SerializeField] private int numberOfHiders = 2;
        [SerializeField] private int hiderMinDistanceFromBlue = 10;

        [Tooltip("Starting max spawn distance. Progressing mode widens this over time; Fixed pins it.")]
        [SerializeField] private int hiderMaxDistanceFromBlue = 11;

        [Header("Progression (Progressing mode only)")]
        [Tooltip("Added to the max distance each time the window clears the threshold.")]
        [SerializeField] private int distanceIncrement = 1;

        [Tooltip("Episodes in the rolling window. Pooled across ALL training areas, since every " +
                 "area runs the same shared policy.")]
        [SerializeField] private int successWindowSize = 10;

        [Tooltip("Fraction of the window that must be full clears to advance. 1 = the original " +
                 "all-or-nothing streak; ~0.8 is less brittle.")]
        [SerializeField] private float successThreshold = 0.8f;

        [Tooltip("Progress file, relative to the project root. Delete it to reset the curriculum.")]
        [SerializeField] private string progressFileName = "curriculum_progress_v2.json";

        [Header("Fixed mode only")]
        [Tooltip("Off = every episode reuses identical spawns, and areas skip re-fetching entirely.")]
        [SerializeField] private bool rerandomiseSpawns = true;

        private Curriculum _curriculum;

        private void Awake()
        {
            List<Map> maps = BuildMaps();
            if (maps.Count == 0)
            {
                Debug.LogError("[SimulationManager] No usable maps -- assign at least one grid text asset.");
                return;
            }

            _curriculum = new Curriculum(maps, CreateStrategy());

            if (spawner == null) spawner = GetComponent<TrainingAreaSpawner>();
            if (spawner == null)
            {
                Debug.LogError("[SimulationManager] No TrainingAreaSpawner assigned or attached.");
                return;
            }

            List<GameObject> areas = spawner.Spawn(LargestAreaFootprint(maps));
            for (int i = 0; i < areas.Count; i++)
                StartArea(areas[i], i);
        }

        // World-space footprint of the biggest map in the curriculum. Sized off the LARGEST rather
        // than the current map because a curriculum can switch maps mid-run and areas are only
        // positioned once -- spacing for the current map would overlap the moment a bigger one loads.
        //
        // gridUnitSize is read from the prefab's own GridManager so there's a single source of truth
        // for it; the area's geometry is centred on its origin, so footprint is cols/rows x that unit.
        private Vector2 LargestAreaFootprint(List<Map> maps)
        {
            float gridUnitSize = 1f;
            if (spawner.BaseArea != null && spawner.BaseArea.TryGetComponent(out GridManager grid))
                gridUnitSize = grid.GridUnitSize;
            else
                Debug.LogWarning("[SimulationManager] Base area has no GridManager; assuming gridUnitSize 1.");

            int maxCols = 0;
            int maxRows = 0;
            foreach (Map map in maps)
            {
                if (map.Cols > maxCols) maxCols = map.Cols;
                if (map.Rows > maxRows) maxRows = map.Rows;
            }

            return new Vector2(maxCols * gridUnitSize, maxRows * gridUnitSize);
        }

        private ICurriculumStrategy CreateStrategy()
        {
            // Purely random hider placement needs no strategy of its own -- it is the fixed strategy
            // with the distance band opened up, so the BFS reaches every walkable cell and the draw
            // is uniform across all of them.
            //
            // minDistance is 1, not 0: at 0 the band includes blue's own starting cells, so a hider
            // could spawn directly on top of an agent and be caught on frame one.
            if (strategy == StrategyMode.Random)
                return new FixedCurriculumStrategy(
                    fixedMapIndex, numberOfBlueAgents, numberOfHiders,
                    minDistance: 1, maxDistance: int.MaxValue, rerandomiseSpawns);

            if (strategy == StrategyMode.Fixed)
                return new FixedCurriculumStrategy(
                    fixedMapIndex, numberOfBlueAgents, numberOfHiders,
                    hiderMinDistanceFromBlue, hiderMaxDistanceFromBlue, rerandomiseSpawns);

            // Project root rather than persistentDataPath: this is research state you want to be able
            // to inspect, diff and delete alongside the run, not something buried in AppData.
            string savePath = Path.Combine(Application.dataPath, "..", progressFileName);

            return new SpawnCurriculumStrategy(
                fixedMapIndex, numberOfBlueAgents, numberOfHiders,
                hiderMinDistanceFromBlue, hiderMaxDistanceFromBlue,
                distanceIncrement, successWindowSize, successThreshold, savePath);
        }

        // Parsed once here and shared by reference with every area -- a Map is immutable, so there's
        // no reason for N areas to each hold their own copy of the same walkability grid.
        private List<Map> BuildMaps()
        {
            List<Map> maps = new();
            if (mapFiles == null) return maps;

            foreach (TextAsset file in mapFiles)
            {
                Map map = new(file);
                if (map.WalkableCells.Count == 0)
                {
                    Debug.LogWarning($"[SimulationManager] Map '{map.Name}' has no walkable cells -- skipping.");
                    continue;
                }
                maps.Add(map);
            }

            return maps;
        }

        private void StartArea(GameObject area, int areaId)
        {
            TrainingAreaManager manager = area.GetComponent<TrainingAreaManager>();
            if (manager == null)
            {
                Debug.LogError($"[SimulationManager] Spawned area '{area.name}' has no TrainingAreaManager.");
                return;
            }

            manager.Initialise(_curriculum.Maps, areaId);
            manager.reportResults = _curriculum.ReportResults;
            manager.tryGetNextEpisode = _curriculum.TryGetNextEpisode;

            // Seeded with no EpisodeResults -- there's no previous episode to describe yet.
            if (!_curriculum.TryGetNextEpisode(out EpisodeConstructionData first))
            {
                Debug.LogWarning($"[SimulationManager] Curriculum supplied no opening episode for '{area.name}'.");
                return;
            }

            manager.Load(first);
            manager.StartRun();
        }
    }
}
