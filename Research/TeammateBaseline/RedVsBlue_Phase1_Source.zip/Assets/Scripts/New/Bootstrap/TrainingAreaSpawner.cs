using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;

namespace RedVsBlue
{
    // Replicates a training area prefab across a flat x/z grid. Same purpose as ML-Agents'
    // TrainingAreaReplicator, but lays areas out on a single plane rather than packing them into a
    // 3D cube, so areas never stack in y.
    //
    // Spawning is driven explicitly by SimulationManager instead of firing from OnEnable, because
    // areas must not exist until the Curriculum they report to has been built. Every area is
    // instantiated from the prefab -- unlike the ML-Agents replicator there's no "skip the first,
    // it's already in the scene" special case, so all areas are uniform and the caller gets a
    // complete list back.
    public class TrainingAreaSpawner : MonoBehaviour
    {
        [SerializeField] private GameObject baseArea;
        [SerializeField] private int numAreas = 1;

        [Tooltip("Empty space left between neighbouring areas, per axis (x, z). The stride is the " +
                 "area's own footprint plus this.")]
        [SerializeField] private Vector2 padding = new(4f, 4f);

        public GameObject BaseArea => baseArea;

        // areaSize is the footprint one area actually occupies in world units. It can't be measured
        // off the prefab: an area builds all its geometry at runtime (GridManager.Build), so the
        // prefab has no renderers and zero bounds at this point. SimulationManager derives it from
        // the map dimensions instead -- see SimulationManager.LargestAreaFootprint.
        public List<GameObject> Spawn(Vector2 areaSize)
        {
            List<GameObject> areas = new();

            if (baseArea == null)
            {
                Debug.LogError("[TrainingAreaSpawner] No base area prefab assigned.");
                return areas;
            }

            // While training, the trainer decides how many areas to run; the inspector value only
            // applies to inference and Editor play. IsCommunicatorOn is the public form of the
            // `Communicator != null` test the package's own replicator uses -- Communicator itself
            // is internal to the ML-Agents assembly and unreachable from here.
            int count = Academy.Instance.IsCommunicatorOn ? Academy.Instance.NumAreas : numAreas;
            count = Mathf.Max(1, count);

            // Footprint + padding, so padding is genuinely the gap between areas rather than a
            // stride that silently overlaps once a map is wider than it.
            float strideX = Mathf.Max(0f, areaSize.x) + padding.x;
            float strideZ = Mathf.Max(0f, areaSize.y) + padding.y;

            int side = Mathf.CeilToInt(Mathf.Sqrt(count));
            for (int i = 0; i < count; i++)
            {
                Vector3 position = new((i % side) * strideX, 0f, (i / side) * strideZ);
                GameObject area = Instantiate(baseArea, position, Quaternion.identity);
                area.name = $"{baseArea.name} {i + 1}";
                areas.Add(area);
            }

            return areas;
        }
    }
}
