using UnityEngine;
using Unity.MLAgents.Sensors;

namespace RedVsBlue
{
    // Attach to the same GameObject as the agent (alongside the existing BufferSensorComponents).
    // Radius matches the old LocalGridRadius/HeatGridRadius (now unified at one radius, one window)
    // used before this moved from flattened vector observations to a proper visual/grid sensor.
    public class LocalGridSensorComponent : SensorComponent
    {
        [SerializeField] private int radius = 5;

        // Samples per tile along each axis -- the window is now rotated to the agent's current heading
        // (see LocalGridSensor), so a 1:1 sample-to-tile ratio aliases badly once most cells land at
        // fractional, non-grid-aligned positions. Supersampling (finer cells over the same physical
        // radius) keeps that aliasing in check; 2 covers the worst-case 45-degree rotation reasonably.
        [SerializeField] private int supersample = 2;

        // Debug-only: lets LocalGridScreenDebug read back the real sensor's last-written values instead of
        // recomputing them itself.
        private LocalGridSensor _sensor;
        public LocalGridSensor GetSensor() => _sensor;

        public override ISensor[] CreateSensors()
        {
            // The area's GridManager is the authority on walkability, and it sits above the agent in
            // the hierarchy -- resolved here rather than through the InfluenceMap's tile Renderers.
            GridManager grid = GetComponentInParent<GridManager>();
            _sensor = new LocalGridSensor(transform, grid, radius, supersample);
            return new ISensor[] { _sensor };
        }
    }
}
