using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace RedVsBlue
{
    // Temporary debug-only HUD: draws LocalGridSensor's actual last-written buffer as a fixed,
    // screen-space grid (never rotates with the agent) -- unlike a Scene-view Gizmo, which is drawn in
    // world space and rotates along with the agent, making an egocentric grid confusing to read.
    // Deliberately kept separate from LocalGridSensor/LocalGridSensorComponent (production code) --
    // this one reads the sensor's real output via LocalGridSensorComponent.GetSensor(), so it shows
    // exactly what the network receives rather than a recomputed copy of the grid.
    //
    // "Forward" is drawn as "up" and "right" as "right", matching the sensor's own (h, w) axes -- i.e. the
    // same orientation the network sees the tensor in, not the world's orientation.
    //
    // One instance goes on EVERY blue agent, and each claims its own panel slot from a shared static
    // registry (see Instances) so the panels tile across the screen instead of stacking on top of one
    // another. Kept as a per-agent component rather than one central HUD that walks the scene: the
    // sensor readback is per-agent state, and this way an agent's HUD lives and dies with the agent.
    public class LocalGridScreenDebug : MonoBehaviour
    {
        [SerializeField] private LocalGridSensorComponent gridSensorComponent;
        [SerializeField] private Key toggleKey = Key.G;
        [SerializeField] private float cellPixelSize = 6f;
        [SerializeField] private Vector2 screenOffset = new Vector2(10f, 10f);
        [SerializeField] private float panelPadding = 12f;

        // A full training run can hold dozens of agents across many areas; past this many panels the
        // screen is unreadable anyway, so later ones are simply not drawn. 0 = no limit.
        [SerializeField] private int maxPanels = 8;

        // Registration order across ALL agents in ALL training areas -- deliberately not the agent's
        // own 1-based id, which repeats once there is more than one area and would put two agents in
        // the same slot. Shared visibility so one keypress toggles the whole wall of panels at once.
        private static readonly List<LocalGridScreenDebug> Instances = new();
        private static bool _visible = true;

        private const float LabelHeight = 16f;

        private Texture2D _whitePixel;
        private AgentController _agentController;

        private void Awake()
        {
            if (gridSensorComponent == null)
                gridSensorComponent = GetComponent<LocalGridSensorComponent>();

            _agentController = GetComponent<AgentController>();

            _whitePixel = new Texture2D(1, 1);
            _whitePixel.SetPixel(0, 0, Color.white);
            _whitePixel.Apply();
        }

        private void OnEnable()
        {
            if (!Instances.Contains(this)) Instances.Add(this);
        }

        private void OnDisable()
        {
            Instances.Remove(this);
        }

        private void Update()
        {
            // Only the first registered instance reads the key: _visible is shared, so letting every
            // instance flip it would toggle it N times per press and leave it unchanged for even N.
            if (Instances.Count > 0 && Instances[0] != this) return;

            // Keyboard.current is null when no keyboard device is attached (e.g. a headless training
            // build) -- this HUD is Editor-debugging-only, so just no-op rather than throw there.
            if (Keyboard.current != null && Keyboard.current[toggleKey].wasPressedThisFrame)
                _visible = !_visible;
        }

        private void OnGUI()
        {
            if (!_visible || gridSensorComponent == null) return;

            LocalGridSensor sensor = gridSensorComponent.GetSensor();
            if (sensor == null) return; // not created yet (e.g. before this agent's first episode)

            int panelIndex = Instances.IndexOf(this);
            if (panelIndex < 0) return;
            if (maxPanels > 0 && panelIndex >= maxPanels) return;

            int size = sensor.Size;
            int half = size / 2;
            float gridPixelSize = size * cellPixelSize;

            // Tile panels left-to-right, wrapping onto a new row when the next one would run off the
            // right edge -- keeps every agent visible without hard-coding a team size.
            float panelWidth = gridPixelSize + panelPadding;
            float panelHeight = gridPixelSize + LabelHeight + panelPadding;
            int columns = Mathf.Max(1, Mathf.FloorToInt((Screen.width - screenOffset.x) / panelWidth));
            float originX = screenOffset.x + (panelIndex % columns) * panelWidth;
            float originY = screenOffset.y + (panelIndex / columns) * panelHeight;

            for (int h = 0; h < size; h++)
            {
                // Flip so larger forwardDist (more "ahead") draws higher on screen.
                float screenRow = size - 1 - h;
                for (int w = 0; w < size; w++)
                {
                    float value = sensor.GetLastWritten(h, w);
                    bool isCentre = h == half && w == half;

                    GUI.color = isCentre ? Color.cyan : Color.Lerp(Color.green, Color.red, value);

                    Rect rect = new Rect(
                        originX + w * cellPixelSize,
                        originY + screenRow * cellPixelSize,
                        cellPixelSize - 1f,
                        cellPixelSize - 1f
                    );
                    GUI.DrawTexture(rect, _whitePixel);
                }
            }

            GUI.color = Color.white;
            int agentId = _agentController != null ? _agentController.GetAgentId() : 0;
            GUI.Label(new Rect(originX, originY + gridPixelSize + 2f, panelWidth, LabelHeight),
                $"Agent {agentId} ({size}x{size})");

            // Legend once, under the whole wall of panels, rather than repeated per agent.
            if (panelIndex != 0) return;
            int shownPanels = maxPanels > 0 ? Mathf.Min(Instances.Count, maxPanels) : Instances.Count;
            int rows = Mathf.CeilToInt(shownPanels / (float)columns);
            GUI.Label(new Rect(screenOffset.x, screenOffset.y + rows * panelHeight, 600f, LabelHeight),
                $"LocalGridSensor — cyan=agent, green=free, red=wall — [{toggleKey}] to toggle ({shownPanels}/{Instances.Count} agents)");
        }
    }
}
