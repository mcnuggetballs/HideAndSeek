using UnityEngine;
using Unity.MLAgents;

namespace RedVsBlue
{
    // Attach to the hider prefab's root, alongside its Collider. Reports its own capture to the
    // area's EpisodeManager when a blue agent touches it. Kept on the hider's own side rather than
    // having blue reach out, so "which object was caught" is always exactly this one -- no parent
    // traversal needed.
    //
    // A caught hider is DEACTIVATED, not destroyed. EpisodeManager reuses instances across episodes
    // anyway, and Destroy() defers the actual native destruction, so a null check made later in the
    // same frame -- e.g. during the very reset this catch triggers -- can't reliably see the object
    // as gone yet. SetActive(false) takes effect immediately, which removes that timing hazard
    // outright (the old RedAgentController needed an explicit synchronous slot-clear to work around
    // it).
    public class RedAgent : MonoBehaviour
    {
        private EpisodeManager _episodes;
        private Collider _collider;

        public void Initialise(EpisodeManager episodes)
        {
            _episodes = episodes;
            _collider = GetComponent<Collider>();
        }

        // Disabled for the whole respawn window: blue is repositioned before hiders are, so until
        // hiders get their new placement a reused instance is still sitting wherever it ended the
        // last episode. If a blue agent's new cell lands on that stale spot, its collider would fire
        // a spurious catch before this hider ever moved.
        public void SetColliderEnabled(bool value)
        {
            if (_collider != null) _collider.enabled = value;
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (_episodes == null) return;

            Agent catcher = collision.gameObject.GetComponentInParent<Agent>();
            if (catcher == null) return;

            gameObject.SetActive(false);
            _episodes.NotifyHiderCaught(this, catcher);
        }
    }
}
