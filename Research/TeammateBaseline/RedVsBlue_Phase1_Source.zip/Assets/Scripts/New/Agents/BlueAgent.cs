using UnityEngine;
using System;
using System.Collections.Generic;
using Unity.MLAgents;
using Unity.MLAgents.Sensors; // Collect observations from the environment
using Unity.MLAgents.Actuators; // Classes related to the actions that the agent can take

namespace RedVsBlue
{
    // One trainable seeker. Purely a sensing/acting shell: it writes observations, turns action
    // buckets into AgentController targets, and remembers sightings.
    //
    // It awards NOTHING and ends NOTHING -- EpisodeManager is the single owner of all reward and of
    // episode lifetime (see its header). Likewise episodes are now PUSHED: EpisodeManager.Begin()
    // repositions the world and only then lets the group episode restart, so OnEpisodeBegin here
    // never reaches out to reset the environment the way the old MultiBlueAgentSearch did.
    public class BlueAgent : Agent
    {
        // Discrete action space: Move (4 options) x Turn (5 options) -- see BehaviorParameters.BranchSizes
        // on the prefab, which must match these lengths. Bucket index -> target value fed straight into
        // AgentController.targetSpeedNormalised/rotationSpeedNormalised, same as the continuous action
        // used to before -- the movement/physics pipeline downstream is unchanged either way.
        private static readonly float[] MoveSpeedByBucket = { -1f, 0f, 0.5f, 1f };       // Full Reverse, Stop, Full Walk, Full Run
        private static readonly float[] TurnRateByBucket = { -1f, -0.5f, 0f, 0.5f, 1f }; // Sharp Left, Left, Straight, Right, Sharp Right

        private AgentController _agentController;
        private GridManager _grid;
        private Vector2 _worldHalfExtents = Vector2.one;
        private float _lastLogTime = -1f;

        // Teammate-sighting memory, fed to the trainer through a BufferSensor (see BufferSensorComponent
        // requirements: ObservableSize must be set to 5 + MaxTeammates in the Inspector, and
        // MaxNumObservables to at least numberOfAgents - 1).
        [SerializeField] private BufferSensorComponent teammatesSensor;
        [SerializeField] private float sightingMemoryDuration = 30f;
        private const int MaxTeammates = 4;

        // Red-agent sighting memory, fed by AgentController's physics-raycast FOV scan (see
        // AgentController.ScanForRedAgents) through RecordRedAgentSighting. Fed to the trainer through a
        // BufferSensor (ObservableSize must be set to 3 + MaxRedAgents in the Inspector, and
        // MaxNumObservables to at least the max number of red agents alive at once).
        [SerializeField] private BufferSensorComponent redAgentsSensor;
        [SerializeField] private float redSightingMemoryDuration = 30f;
        private const int MaxRedAgents = 4;
        private struct RedSighting { public float seenTime; public Vector3 localPosition; }
        private readonly Dictionary<int, RedSighting> _rememberedRedSightings = new();

        // heading is a smoothed (EMA), normalised recent-movement direction in local space -- Vector3.zero
        // until the first update after this teammate is first recorded. See RecordTeammateSighting.
        private struct TeammateSighting { public float seenTime; public Vector3 localPosition; public Vector3 heading; }

        // Time constant (in seconds, not frames) for the teammate heading EMA -- keeps the effective
        // lookback window fixed in real/game time regardless of framerate or Time.timeScale, rather than
        // depending on how many Update() calls happened to occur. Lower = reacts to direction changes
        // faster but noisier; higher = smoother but laggier.
        [SerializeField] private float teammateHeadingTimeConstant = 0.25f;
        private readonly Dictionary<int, TeammateSighting> _rememberedSightings = new();

        private int _agentId = -1;

        [HideInInspector] public int CurrentEpisode = 0;

        public override void Initialize()
        {
            // Initialise the agent, set up any necessary variables or references or components
            Debug.Log("Blue Agent Initialize()");

            _agentController = GetComponent<AgentController>();

            // The area's GridManager sits above this agent in the hierarchy (same lookup
            // LocalGridSensorComponent uses), so no spawner hand-off is needed just to read the
            // map's dimensions.
            _grid = GetComponentInParent<GridManager>();

            CurrentEpisode = 0;
        }

        // Resets ONLY this agent's own per-episode state. The world is repositioned by
        // EpisodeManager.Begin() before the group episode restarts, so there is deliberately no
        // environment reset call here (the old code pulled one, which meant every agent independently
        // asked the environment to rebuild itself).
        public override void OnEpisodeBegin()
        {
            if (CurrentEpisode > 0)
                Debug.Log($"[EpisodeEnd] Episode {CurrentEpisode} | Steps: {StepCount}");

            // Resolved here rather than in Initialize(): Instantiate() synchronously fires this agent's own
            // Initialize() before the spawner gets a chance to call AgentController.Initialise() (which is
            // where the ID actually gets assigned), so reading it any earlier would capture the unset default.
            if (_agentId < 0 && _agentController != null)
            {
                _agentId = _agentController.GetAgentId();
                if (_agentId < 1 || _agentId > MaxTeammates)
                    Debug.LogWarning($"[BlueAgent] Agent ID {_agentId} is outside the one-hot range [1, {MaxTeammates}] — teammate sightings involving this agent will be reported without identity.");
            }

            // Sightings are episode-scoped: carrying them over would report positions from a map/layout
            // that no longer exists, with a recency that makes them look fresh.
            _rememberedSightings.Clear();
            _rememberedRedSightings.Clear();

            CurrentEpisode++;

            Debug.Log($"[EpisodeStart] Episode {CurrentEpisode} | Agent: ({transform.localPosition.x:F1}, {transform.localPosition.z:F1})");
        }

        // Half the map's world-space footprint, used to normalise every position observation into
        // roughly [-1, 1]. Read live from the grid rather than cached at episode start: episodes are
        // pushed now, so EpisodeManager.Begin() (and any curriculum map switch with it) runs AFTER
        // OnEpisodeBegin -- a value cached there would be one map behind. Two multiplies per read.
        private Vector2 GetWorldHalfExtents() => _grid != null && _grid.Rows > 0
            ? new Vector2(_grid.Cols * _grid.GridUnitSize / 2f, _grid.Rows * _grid.GridUnitSize / 2f)
            : Vector2.one;

        // VectorSensor: serves as a container for the observations collected from the environment
        public override void CollectObservations(VectorSensor sensor)
        {
            // Collect observations from the environment and add them to the sensor
            // Various data types can be observed, such as positions, velocities, distances, angles, etc.
            // These observations will be used by the agent to make decisions

            // Tip #1: normalise the observations which helps the agent learn more effectively
            // Tip #2: use local position & rotation instead of global so we can duplicate the environment later and train multiple agents

            _worldHalfExtents = GetWorldHalfExtents();

            // The Agent's position
            float agentPosX_normalised = transform.localPosition.x / _worldHalfExtents.x;
            float agentPosZ_normalised = transform.localPosition.z / _worldHalfExtents.y;

            // The Agent's facing direction as sin/cos components (x = East/West, z = North/South, each in [-1, 1]).
            //Vector3 agentForward = transform.forward;
            Vector3 agentForward = transform.parent.InverseTransformDirection(transform.forward);

            // Add all observations to the sensor
            sensor.AddObservation(agentPosX_normalised);
            sensor.AddObservation(agentPosZ_normalised);
            sensor.AddObservation(agentForward.x); // East (+1) / West (-1) component of facing direction
            sensor.AddObservation(agentForward.z); // North (+1) / South (-1) component of facing direction

            // Go to Behaviour Parameters > Vector Observation > Space Size and set it to 4 --
            // wall/seen/heat and the whole-map summary now come from LocalGridSensorComponent and
            // GlobalGridSensorComponent instead (see those + network_settings.vis_encode_type).

            WriteTeammateSightingObservations();
            WriteRedSightingObservations();
        }

        public override void Heuristic(in ActionBuffers actionsOut)
        {
            // Define a heuristic for testing the agent's behaviour without training
            // This allows you to manually control the agent using keyboard input or other means

            _agentController.GetKeyboardInputs();

            var disc = actionsOut.DiscreteActions;
            disc[0] = Array.IndexOf(MoveSpeedByBucket, _agentController.targetSpeedNormalised);
            disc[1] = Array.IndexOf(TurnRateByBucket, _agentController.rotationSpeedNormalised);
        }

        // ActionBuffers: holds the actions that the agent can take, which are determined by the policy (the neural network) during training or inference
        public override void OnActionReceived(ActionBuffers actions)
        {
            // Perform actions based on the received action buffers
            // This is where you would implement the logic for how the agent should respond to the actions it takes

            // Move the agent using the action.
            MoveAgent(actions.DiscreteActions);

            // No reward is applied here. Time pressure, isolation and catch rewards are all applied
            // once per environment step by EpisodeManager (see EpisodeManager.FixedUpdate) -- applying
            // any of them per-agent here would scale them by team size.
        }

        // Public entry point for external sighting-detection logic (FOV/LOS scan, implemented separately)
        // to report that this agent has just seen a teammate. Overwrites any previous memory of that
        // teammate with the latest sighting. teammateId should match the sighted agent's 1-based slot in
        // EpisodeManager.BlueAgents.
        public void RecordTeammateSighting(int teammateId, Vector3 teammateWorldPosition)
        {
            Vector3 newLocalPosition = transform.parent.InverseTransformPoint(teammateWorldPosition);

            // Smoothed (EMA) recent-movement direction -- raw frame-to-frame position deltas are too noisy
            // to use directly (teammates barely move between consecutive calls), so blend into a running
            // heading estimate instead of replacing it outright each call. A near-zero delta this call
            // (teammate essentially stationary) keeps the previous heading rather than snapping to zero.
            Vector3 heading = Vector3.zero;
            if (_rememberedSightings.TryGetValue(teammateId, out TeammateSighting previous))
            {
                heading = previous.heading;
                Vector3 delta = newLocalPosition - previous.localPosition;
                if (delta.sqrMagnitude > 0.0001f)
                {
                    // Time-constant-based blend factor (not a flat per-call one) so the effective lookback
                    // window stays fixed in seconds regardless of framerate or Time.timeScale.
                    float alpha = 1f - Mathf.Exp(-Time.deltaTime / teammateHeadingTimeConstant);
                    heading = Vector3.Lerp(previous.heading, delta.normalized, alpha).normalized;
                }
            }

            _rememberedSightings[teammateId] = new TeammateSighting
            {
                seenTime = Time.time,
                localPosition = newLocalPosition,
                heading = heading
            };
        }

        // Public entry point for AgentController's physics-raycast FOV scan (see
        // AgentController.ScanForRedAgents) to report a red-agent sighting. Called on every teammate,
        // not just whichever agent's raycast actually spotted it -- a sighting is shared team-wide the
        // instant anyone sees it. Overwrites any previous memory of that red agent with the latest
        // sighting. redAgentId is that hider's stable slot index (see AgentController.IndexOfRedAgent).
        public void RecordRedAgentSighting(int redAgentId, Vector3 redAgentWorldPosition)
        {
            _rememberedRedSightings[redAgentId] = new RedSighting
            {
                seenTime = Time.time,
                localPosition = transform.parent.InverseTransformPoint(redAgentWorldPosition)
            };
        }

        // Feeds one entity per remembered red-agent sighting into the BufferSensor: [recency, x, z,
        // one-hot ID]. Same stale-pruning behaviour as WriteTeammateSightingObservations -- sightings
        // older than redSightingMemoryDuration are forgotten so stale info stops being reported.
        private void WriteRedSightingObservations()
        {
            if (redAgentsSensor == null) return;

            List<int> staleKeys = null;
            foreach (var kvp in _rememberedRedSightings)
            {
                if (Time.time - kvp.Value.seenTime <= redSightingMemoryDuration) continue;
                staleKeys ??= new List<int>();
                staleKeys.Add(kvp.Key);
            }
            if (staleKeys != null)
                foreach (int key in staleKeys)
                    _rememberedRedSightings.Remove(key);

            foreach (var kvp in _rememberedRedSightings)
            {
                RedSighting sighting = kvp.Value;
                float recency = Mathf.Clamp01((Time.time - sighting.seenTime) / redSightingMemoryDuration);

                float[] entity = new float[redAgentsSensor.ObservableSize];
                entity[0] = recency;
                entity[1] = sighting.localPosition.x / _worldHalfExtents.x;
                entity[2] = sighting.localPosition.z / _worldHalfExtents.y;

                int redAgentId = kvp.Key; // 0-based hider slot index
                if (redAgentId >= 0 && redAgentId < MaxRedAgents)
                    entity[3 + redAgentId] = 1f;

                redAgentsSensor.AppendObservation(entity);
            }
        }

        // Feeds one entity per remembered teammate sighting into the BufferSensor:
        // [recency, x, z, headingX, headingZ, one-hot ID]. Padding for unused slots (up to
        // MaxNumObservables) and masking are handled automatically by the sensor. Sightings older than
        // sightingMemoryDuration are forgotten here so stale info eventually stops being reported at all.
        private void WriteTeammateSightingObservations()
        {
            if (teammatesSensor == null) return;

            List<int> staleKeys = null;
            foreach (var kvp in _rememberedSightings)
            {
                if (Time.time - kvp.Value.seenTime <= sightingMemoryDuration) continue;
                staleKeys ??= new List<int>();
                staleKeys.Add(kvp.Key);
            }
            if (staleKeys != null)
                foreach (int key in staleKeys)
                    _rememberedSightings.Remove(key);

            bool shouldLog = Time.time - _lastLogTime >= 1f;
            shouldLog = false;
            if (shouldLog)
                Debug.Log($"[TeammateSightings] Agent {_agentId} | {_rememberedSightings.Count} remembered");

            foreach (var kvp in _rememberedSightings)
            {
                TeammateSighting sighting = kvp.Value;
                float recency = Mathf.Clamp01((Time.time - sighting.seenTime) / sightingMemoryDuration);

                float[] entity = new float[teammatesSensor.ObservableSize];
                entity[0] = recency;
                entity[1] = sighting.localPosition.x / _worldHalfExtents.x;
                entity[2] = sighting.localPosition.z / _worldHalfExtents.y;
                entity[3] = sighting.heading.x; // already normalised (or zero if no movement recorded yet)
                entity[4] = sighting.heading.z;

                int teammateId = kvp.Key;
                if (teammateId >= 1 && teammateId <= MaxTeammates)
                    entity[5 + (teammateId - 1)] = 1f;

                teammatesSensor.AppendObservation(entity);

                if (shouldLog)
                    Debug.Log($"  observer {_agentId} sees teammate {teammateId} | recency={recency:F2} | localPos=({sighting.localPosition.x:F1}, {sighting.localPosition.z:F1}) | heading=({sighting.heading.x:F2}, {sighting.heading.z:F2}) | entity=[{string.Join(", ", Array.ConvertAll(entity, v => v.ToString("F2")))}]");
            }
        }

        // ActionSegment: a discrete segment of the action buffer that contains the specific actions for the agent to take
        public void MoveAgent(ActionSegment<int> discActions)
        {
            _agentController.targetSpeedNormalised = MoveSpeedByBucket[discActions[0]];
            _agentController.rotationSpeedNormalised = TurnRateByBucket[discActions[1]];
        }
    }
}
