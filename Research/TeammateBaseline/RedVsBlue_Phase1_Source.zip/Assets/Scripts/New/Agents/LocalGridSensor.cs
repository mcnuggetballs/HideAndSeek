using UnityEngine;
using Unity.MLAgents.Sensors;

namespace RedVsBlue
{
    // Egocentric (2*radius*supersample+1)^2 window centred on AND rotated to the agent's own current
    // heading -- "forward" is always the same fixed axis in the tensor regardless of which way the agent
    // is actually facing, so the CNN encoder only ever has to learn one canonical "wall ahead" pattern
    // instead of one entangled with heading (see Cognitive Mapping and Planning for Visual Navigation,
    // Gupta et al. CVPR 2017, on why a world-fixed frame makes this a harder function to learn).
    //
    // Sampling at the underlying tile grid's own resolution (1 sample per gridUnitSize) works cleanly
    // unrotated -- every cell lines up 1:1 with a source tile -- but once rotated, most cells land at
    // fractional, non-grid-aligned positions, and a 1:1 ratio is the worst case for aliasing. supersample
    // oversamples (finer cells over the same physical radius) to keep that in check; nearest-neighbour
    // (not bilinear) is used deliberately since wall/walkable is categorical data, not something that
    // should be blended into fractional "half-wall" values.
    public class LocalGridSensor : ISensor
    {
        private readonly Transform _agentTransform;
        private readonly GridManager _grid;
        private readonly int _radius;
        private readonly int _supersample;
        private readonly int _size;
        private readonly ObservationSpec _spec;

        // Debug-only: the exact values handed to `writer` on the last Write() call, so an external HUD can
        // display literally what the network received instead of a separately-reimplemented recomputation
        // (see LocalGridScreenDebug, which reads this rather than re-deriving the grid itself).
        private readonly float[] _lastWritten;
        public int Size => _size;
        public float GetLastWritten(int h, int w) => _lastWritten[h * _size + w];

        public LocalGridSensor(Transform agentTransform, GridManager grid, int radius, int supersample)
        {
            _agentTransform = agentTransform;
            _grid = grid;
            _radius = radius;
            _supersample = Mathf.Max(1, supersample);
            _size = 2 * radius * _supersample + 1;
            _lastWritten = new float[_size * _size];
            // Channels, then height, then width -- matches ObservationSpec.Visual's parameter order.
            _spec = ObservationSpec.Visual(1, _size, _size);
        }

        public ObservationSpec GetObservationSpec() => _spec;

        public int Write(ObservationWriter writer)
        {
            // No grid to sample means "everything is wall" rather than "everything is open" -- an
            // unresolved reference should never look like a safe, empty world to the policy.
            if (_grid == null)
            {
                for (int h = 0; h < _size; h++)
                    for (int w = 0; w < _size; w++)
                    {
                        writer[0, h, w] = 1f;
                        _lastWritten[h * _size + w] = 1f;
                    }
                return _size * _size;
            }

            float cellSize = _grid.GridUnitSize / _supersample;
            int half = _radius * _supersample;

            // Flattened to the XZ plane and normalised -- yaw only, pitch/roll (e.g. head look) shouldn't
            // rotate the ground-plane sampling window.
            Vector3 forward = _agentTransform.forward;
            Vector3 right = _agentTransform.right;
            forward.y = 0f;
            right.y = 0f;
            forward = forward.sqrMagnitude > 0.0001f ? forward.normalized : Vector3.forward;
            right = right.sqrMagnitude > 0.0001f ? right.normalized : Vector3.right;

            Vector3 agentWorldPos = _agentTransform.position;

            for (int h = 0; h < _size; h++)
            {
                float forwardDist = (h - half) * cellSize;
                for (int w = 0; w < _size; w++)
                {
                    float rightDist = (w - half) * cellSize;
                    Vector3 sampleWorldPos = agentWorldPos + forward * forwardDist + right * rightDist;
                    Vector2Int gridPos = _grid.WorldToGrid(sampleWorldPos);

                    // Walkability comes from the map data, not from whether a tile Renderer happens to
                    // exist there (which is what the old influenceMap.GetTile(...) == null test really
                    // asked). Out-of-bounds samples answer false, i.e. wall -- correct, since the map
                    // edge is not somewhere the agent can walk.
                    bool isWall = !_grid.IsWalkable(gridPos.y, gridPos.x);
                    float value = isWall ? 1f : 0f;
                    writer[0, h, w] = value;
                    _lastWritten[h * _size + w] = value;
                }
            }

            return _size * _size;
        }

        public byte[] GetCompressedObservation() => null;
        public void Update() { }
        public void Reset() { }
        public CompressionSpec GetCompressionSpec() => CompressionSpec.Default();
        public string GetName() => "LocalGridSensor";
    }
}
