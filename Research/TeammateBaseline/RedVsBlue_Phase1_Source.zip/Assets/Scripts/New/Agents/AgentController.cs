/*
AgentController.cs
Author: Loh Shao Cong
Version: 2.1
Date: 16/06/2026
Description: A general Unity script for humanoid character movement and animation control.
Note: Modified from the original for the RedVsBlue project.
*/

using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;
using Unity.MLAgents;

namespace RedVsBlue
{
    public class AgentController : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private Transform headBone;
        [SerializeField] private InfluenceMap influenceMap;
        [SerializeField] private GridManager grid;

        // Target parameters (Normalised values between -1 and 1)
        // Values here are input by the user or an external system to set the target values
        [Header("Target Parameters")]
        [SerializeField] public float targetSpeedNormalised = 0f;
        [SerializeField] public float rotationSpeedNormalised = 0f;
        [SerializeField] public float headPitchNormalised = 0f;
        [SerializeField] public float headYawNormalised = 0f;
        [SerializeField] public bool crouchEnabled = false;

        // Keyboard input speed parameters (Normalised values between -1 and 1)
        [Header("Keyboard Input Parameters")]
        [Tooltip("Manual driving for inference/testing. Ignored while a trainer is attached.")]
        [SerializeField] private bool useKeyboardInput = true;

        // useKeyboardInput AND no trainer attached. GetKeyboardInputs writes the same
        // targetSpeedNormalised / rotationSpeedNormalised fields the policy's actions write, and
        // zeroes them whenever no key is held -- so leaving it live during training means an idle
        // keyboard fights the policy every frame, and a stray keypress corrupts the run outright.
        // Resolved once in Start: whether a trainer is connected can't change mid-run.
        private bool _keyboardEnabled;
        [SerializeField] private float walkForwardSpeedKeyboard = 0.5f;
        [SerializeField] private float runForwardSpeedKeyboard = 1f;
        [SerializeField] private float crouchForwardSpeedKeyboard = 1f;
        [SerializeField] private float crouchBackwardSpeedKeyboard = 1f;
        [SerializeField] private float walkBackwardsSpeedKeyboard = 1f;
        [SerializeField] private float rotateSpeedKeyboard = 1f;
        [SerializeField] private float headPitchKeyboard = 1f;
        [SerializeField] private float headYawKeyboard = 1f;

        // Movement behaviour toggles
        [Header("Movement Behaviour")]
        [SerializeField] private bool intuitiveReverseSteering = true;

        // A fan of physics raycasts across the agent's field of view, used to spot red agents (tagged
        // "Goal") -- separate from InfluenceMap's grid-cell LOS check used for tile-exploration
        // accounting (see UpdateAgentObservations), since this one needs real physics blocking (a wall
        // between the agent and a red agent should hide it) rather than tile-grid visibility.
        [Header("Red Agent Vision")]
        [SerializeField] private int numberOfRays = 9;
        [SerializeField] private float visionRange = 15f;
        [SerializeField] private float fovHalfAngle = 60f;
        [SerializeField] private LayerMask redAgentVisionMask = ~0;

        // Movement parameters
        private float acceleration = 5f;
        private float rotationAcceleration = 200f; // Currently unused, rotation speed set directly
        private float headRotationAcceleration = 200f;
        private float maxStandForwardSpeed = 5.0f;
        private float maxStandBackwardSpeed = 1.5f;
        private float maxCrouchForwardSpeed = 1.5f;
        private float maxCrouchBackwardSpeed = 1.5f;
        private float maxRotationSpeed = 100f;
        private float maxHeadYaw = 70f;
        private float maxHeadPitchUp = 60f;
        private float maxHeadPitchDown = 40f;

        // Animator reference and hashes
        private Animator animator;
        private int speedHash;
        private int rotateHash;
        private int crouchHash;
        private int isMovingHash;

        // Runtime variables
        private float currentSpeed = 0f;
        private float currentBaseSpeed = 0f;
        private float targetSpeed = 0f;
        private float targetBaseSpeed = 0f;
        private float currentSpeedNormalised = 0f;
        private float rotationSpeed = 0f;
        private float targetRotationSpeed = 0f;
        private float currentHeadPitch = 0f;
        private float currentHeadYaw = 0f;
        private float targetHeadPitch = 0f;
        private float targetHeadYaw = 0f;

        // Initialisation variables
        private Rigidbody rb;
        private BlueAgent _agent;
        private EpisodeManager _episodes;
        private int _agentId = 0;

        // Called by EpisodeManager the moment this instance is created, before its first Start().
        public void Initialise(InfluenceMap map, GridManager gridManager, int agentId)
        {
            influenceMap = map;
            grid = gridManager;
            _agent = GetComponent<BlueAgent>();
            _agentId = agentId;
        }

        public int GetAgentId() => _agentId;

        public float GetHeadPitch()
        {
            return currentHeadPitch < 0f ? currentHeadPitch / maxHeadPitchUp : currentHeadPitch / maxHeadPitchDown;
        }

        public float GetHeadYaw()
        {
            return currentHeadYaw / maxHeadYaw;
        }

        // Resolved lazily rather than in Start(): EpisodeManager can call UpdateAgentObservations on
        // the same physics tick that instantiated this agent, which is before Start() has run.
        // Agents are parented to the EpisodeManager's own transform, so this always finds the area
        // that owns them.
        private EpisodeManager Episodes => _episodes != null
            ? _episodes
            : _episodes = GetComponentInParent<EpisodeManager>();

        void Start()
        {
            animator = GetComponent<Animator>();
            rb = GetComponent<Rigidbody>();

            // Fallbacks for scenes that place an agent by hand (e.g. keyboard-driven testing) rather
            // than going through EpisodeManager's Initialise hand-off.
            if (grid == null) grid = GetComponentInParent<GridManager>();
            if (influenceMap == null) influenceMap = GetComponentInParent<InfluenceMap>();
            if (_agent == null) _agent = GetComponent<BlueAgent>();

            _keyboardEnabled = useKeyboardInput && !Academy.Instance.IsCommunicatorOn;

            // Cache animator parameter hashes for performance
            speedHash = Animator.StringToHash("currentSpeedNormalised");
            rotateHash = Animator.StringToHash("rotationSpeedNormalised");
            crouchHash = Animator.StringToHash("crouchEnabled");
            isMovingHash = Animator.StringToHash("isMoving");
        }

        void Update()
        {
            if (_keyboardEnabled) GetKeyboardInputs();

            // Calculate normalised speed for animator
            currentSpeedNormalised = currentBaseSpeed == 0f ? 0f : currentSpeed / currentBaseSpeed;

            // Feed animator
            animator.SetFloat(speedHash, currentSpeedNormalised, 0.1f, Time.deltaTime);
            animator.SetFloat(rotateHash, rotationSpeedNormalised, 0.1f, Time.deltaTime);
            animator.SetBool(crouchHash, crouchEnabled);
            animator.SetBool(isMovingHash, currentSpeed != 0f);
        }

        // Driven once per environment step by EpisodeManager, in a two-pass loop (every agent's
        // position is written to the influence map before ANY agent's LOS check reads it) -- see
        // EpisodeManager.UpdateAgentPerception.
        //
        // Returns the number of tiles this agent saw for the first time this step, so the reward
        // owner (EpisodeManager) can price exploration. Nothing consumes it yet; it is returned
        // rather than dropped because it is already computed here and recovering it later would
        // mean re-running the whole LOS sweep.
        public int UpdateAgentObservations()
        {
            // Get current bearing and update influence map
            Vector3 headPosition = headBone != null ? headBone.position : transform.position;
            Vector3 forward = headBone != null ? headBone.forward : transform.forward;
            float bearing = Mathf.Atan2(forward.x, forward.z) * Mathf.Rad2Deg;
            if (bearing < 0f) bearing += 360f;

            ScanForRedAgents(headPosition, bearing);

            if (influenceMap == null || grid == null) return 0;
            (int observedCount, int newObservedCount, HashSet<int> observedAgentsInFOV) = influenceMap.UpdateAgentObservations(
                                                            grid.WorldToGrid(transform.position),
                                                            bearing,
                                                            _agentId
                                                        );

            // Feed each teammate spotted this frame into the agent's sighting memory.
            // Disabled: teammates are now always known (see below) rather than gated by line-of-sight.
            // Re-enable by uncommenting this block and commenting out the "always known" block underneath.
            //if (_agent != null && Episodes != null)
            //{
            //    IReadOnlyList<Transform> teammates = Episodes.BlueAgents;
            //    foreach (int teammateId in observedAgentsInFOV)
            //    {
            //        int index = teammateId - 1; // IDs are 1-based, BlueAgents is 0-based
            //        if (index < 0 || index >= teammates.Count) continue;
            //
            //        _agent.RecordTeammateSighting(teammateId, teammates[index].position);
            //    }
            //}

            // Feed every teammate's current position into the agent's sighting memory every step --
            // teammates are always known, not gated by line-of-sight.
            if (_agent != null && Episodes != null)
            {
                IReadOnlyList<Transform> teammates = Episodes.BlueAgents;
                for (int index = 0; index < teammates.Count; index++)
                {
                    int teammateId = index + 1; // IDs are 1-based, BlueAgents is 0-based
                    if (teammateId == _agentId) continue; // don't report seeing yourself

                    _agent.RecordTeammateSighting(teammateId, teammates[index].position);
                }
            }

            return newObservedCount;
        }

        // Fires a fan of physics raycasts across [bearing - fovHalfAngle, bearing + fovHalfAngle] looking
        // for red agents (tagged "Goal"). A ray's first hit blocks it (e.g. a wall), so this is a real
        // physics line-of-sight check rather than the grid-cell visibility InfluenceMap uses above.
        // Unlike teammate position (always known to everyone already), a red-agent sighting only exists
        // once someone actually spots it -- so a hit is broadcast to every blue teammate's own memory,
        // not just this agent's.
        private void ScanForRedAgents(Vector3 origin, float bearing)
        {
            EpisodeManager episodes = Episodes;
            if (episodes == null) return;

            int rayCount = Mathf.Max(1, numberOfRays);
            HashSet<int> spottedThisFrame = null;

            for (int i = 0; i < rayCount; i++)
            {
                Vector3 direction = GetFanRayDirection(bearing, i, rayCount);
                if (!Physics.Raycast(origin, direction, out RaycastHit hit, visionRange, redAgentVisionMask)) continue;
                if (!hit.collider.CompareTag("Goal")) continue;

                RedAgent red = hit.collider.GetComponentInParent<RedAgent>();
                if (red == null) continue;

                int redAgentId = IndexOfRedAgent(red);
                if (redAgentId < 0) continue;

                // Multiple rays can land on the same red agent in one frame -- only broadcast it once.
                spottedThisFrame ??= new HashSet<int>();
                if (!spottedThisFrame.Add(redAgentId)) continue;

                foreach (Transform teammate in episodes.BlueAgents)
                {
                    if (teammate == null) continue;
                    teammate.GetComponent<BlueAgent>()?.RecordRedAgentSighting(redAgentId, hit.point);
                }
            }
        }

        // A sighting is broadcast to the whole team under a single id, so that id has to be the same
        // answer for every observer. EpisodeManager.Hiders is the authority: position in that list is
        // the id, it's stable for the run (instances are reused, not recreated), and every agent
        // reads the same list -- no hierarchy-order assumption and no allocation.
        private int IndexOfRedAgent(RedAgent red)
        {
            EpisodeManager episodes = Episodes;
            if (episodes == null) return -1;

            IReadOnlyList<RedAgent> hiders = episodes.Hiders;
            for (int i = 0; i < hiders.Count; i++)
                if (hiders[i] == red) return i;

            return -1;
        }

        // Direction of ray `rayIndex` of `rayCount`, evenly fanned across the FOV cone. Shared by
        // ScanForRedAgents and the editor gizmo so the drawn cone always matches what's actually cast.
        private Vector3 GetFanRayDirection(float bearing, int rayIndex, int rayCount)
        {
            float t = rayCount <= 1 ? 0.5f : (float)rayIndex / (rayCount - 1);
            float angle = bearing - fovHalfAngle + t * (2f * fovHalfAngle);
            float rad = angle * Mathf.Deg2Rad;
            return new Vector3(Mathf.Sin(rad), 0f, Mathf.Cos(rad));
        }

        // Draws the red-agent vision cone in the Scene view while this agent is selected. Actually casts
        // each ray (same as ScanForRedAgents) rather than always drawing full length, so a wall visibly
        // stops the line at the point it would really be blocked -- green = clear line of sight to
        // visionRange, yellow = blocked by something other than a red agent, red = a red agent was hit.
        private void OnDrawGizmosSelected()
        {
            Transform origin = headBone != null ? headBone : transform;
            Vector3 forward = origin.forward;
            float bearing = Mathf.Atan2(forward.x, forward.z) * Mathf.Rad2Deg;

            int rayCount = Mathf.Max(1, numberOfRays);
            for (int i = 0; i < rayCount; i++)
            {
                Vector3 direction = GetFanRayDirection(bearing, i, rayCount);
                bool didHit = Physics.Raycast(origin.position, direction, out RaycastHit hit, visionRange, redAgentVisionMask);
                bool hitRedAgent = didHit && hit.collider.CompareTag("Goal");

                Gizmos.color = hitRedAgent ? Color.red : didHit ? Color.yellow : Color.green;
                float length = didHit ? hit.distance : visionRange;
                Gizmos.DrawRay(origin.position, direction * length);

                if (didHit)
                    Gizmos.DrawSphere(hit.point, 0.15f);
            }
        }

        void FixedUpdate()
        {
            // Set current and target base speeds
            if (crouchEnabled)
            {
                currentBaseSpeed = currentSpeed >= 0 ? maxCrouchForwardSpeed : maxCrouchBackwardSpeed;
                targetBaseSpeed = targetSpeedNormalised >= 0 ? maxCrouchForwardSpeed : maxCrouchBackwardSpeed;
            }
            else
            {
                currentBaseSpeed = currentSpeed >= 0 ? maxStandForwardSpeed : maxStandBackwardSpeed;
                targetBaseSpeed = targetSpeedNormalised >= 0 ? maxStandForwardSpeed : maxStandBackwardSpeed;
            }

            //=================
            // SPEED
            //=================

            // Calculate target speed
            targetSpeed = targetSpeedNormalised * targetBaseSpeed;

            // Transition current speed towards target speed smoothly
            currentSpeed = Mathf.MoveTowards(
                currentSpeed,
                targetSpeed,
                acceleration * Time.fixedDeltaTime // Use Time.fixedDeltaTime for consistent movement regardless of frame rate
            );

            //=================
            // ROTATION
            //=================

            // Calculate target rotation speed
            targetRotationSpeed = rotationSpeedNormalised * maxRotationSpeed;

            /*
            // Transition current rotation speed towards target speed smoothly (Currently UNUSED)
            rotationSpeed = Mathf.MoveTowards(
                rotationSpeed,
                targetRotationSpeed,
                rotationAcceleration * Time.fixedDeltaTime // Use Time.fixedDeltaTime for consistent movement regardless of frame rate
            );
            */

            // Directly set rotation speed (Currently used)
            rotationSpeed = targetRotationSpeed;

            // Move the agent
            MoveAgent(currentSpeed, rotationSpeed);
        }

        void LateUpdate()
        {
            //=================
            // HEAD MOVEMENT
            //=================

            // Calculate target head rotation
            targetHeadPitch = headPitchNormalised >= 0 ? headPitchNormalised * maxHeadPitchDown : headPitchNormalised * maxHeadPitchUp;
            targetHeadYaw = headYawNormalised * maxHeadYaw;

            // Transition current head rotation towards target head rotation smoothly
            currentHeadPitch = Mathf.MoveTowards(
                currentHeadPitch,
                targetHeadPitch,
                headRotationAcceleration * Time.deltaTime
            );
            currentHeadYaw = Mathf.MoveTowards(
                currentHeadYaw,
                targetHeadYaw,
                headRotationAcceleration * Time.deltaTime
            );

            UpdateHeadRotation();
        }

        public void GetKeyboardInputs()
        {
            bool forwardPressed = Keyboard.current.wKey.isPressed;
            bool backwardPressed = Keyboard.current.sKey.isPressed;
            bool rotateLeftPressed = Keyboard.current.aKey.isPressed;
            bool rotateRightPressed = Keyboard.current.dKey.isPressed;
            bool runPressed = Keyboard.current.leftShiftKey.isPressed;
            bool crouchPressed = Keyboard.current.spaceKey.wasPressedThisFrame;
            bool lookLeftPressed = Keyboard.current.leftArrowKey.isPressed;
            bool lookRightPressed = Keyboard.current.rightArrowKey.isPressed;
            bool lookUpPressed = Keyboard.current.upArrowKey.isPressed;
            bool lookDownPressed = Keyboard.current.downArrowKey.isPressed;

            // Movement input (Walk, Run, Crouch)
            if (crouchEnabled)
            {
                if (forwardPressed && !backwardPressed)
                {
                    targetSpeedNormalised = crouchForwardSpeedKeyboard;
                }
                else if (!forwardPressed && backwardPressed)
                {
                    targetSpeedNormalised = -crouchBackwardSpeedKeyboard;
                }
                else
                {
                    targetSpeedNormalised = 0f;
                }
            }
            else
            {
                if (forwardPressed && !backwardPressed && runPressed)
                {
                    targetSpeedNormalised = runForwardSpeedKeyboard;
                }
                else if (forwardPressed && !backwardPressed && !runPressed)
                {
                    targetSpeedNormalised = walkForwardSpeedKeyboard;
                }
                else if (!forwardPressed && backwardPressed)
                {
                    targetSpeedNormalised = -walkBackwardsSpeedKeyboard;
                }
                else
                {
                    targetSpeedNormalised = 0f;
                }
            }

            // Rotation input
            if (rotateLeftPressed && !rotateRightPressed)
            {
                rotationSpeedNormalised = -rotateSpeedKeyboard;
            }
            else if (rotateRightPressed && !rotateLeftPressed)
            {
                rotationSpeedNormalised = rotateSpeedKeyboard;
            }
            else
            {
                rotationSpeedNormalised = 0f;
            }

            // Toggle crouch state on space key press
            if (crouchPressed)
            {
                crouchEnabled = !crouchEnabled;
            }

            // Head rotation
            if (lookUpPressed && !lookDownPressed)
            {
                headPitchNormalised = -headPitchKeyboard;
            }
            else if (!lookUpPressed && lookDownPressed)
            {
                headPitchNormalised = headPitchKeyboard;
            }
            else
            {
                headPitchNormalised = 0f;
            }

            if (lookLeftPressed && !lookRightPressed)
            {
                headYawNormalised = -headYawKeyboard;
            }
            else if (!lookLeftPressed && lookRightPressed)
            {
                headYawNormalised = headYawKeyboard;
            }
            else
            {
                headYawNormalised = 0f;
            }
        }

        void MoveAgent(float currentSpeed, float rotationSpeed)
        {
            float effectiveRotationSpeed = intuitiveReverseSteering && currentSpeed < 0f ? -rotationSpeed : rotationSpeed;

            // Move the agent using rb.MovePosition to prevent phasing through walls
            Vector3 worldDir = transform.TransformDirection(Vector3.forward);
            rb.MovePosition(rb.position + worldDir * (currentSpeed * Time.fixedDeltaTime));

            // Rotate the agent via MoveRotation to stay consistent with physics (avoids residual angular velocity)
            Quaternion deltaRotation = Quaternion.Euler(0f, effectiveRotationSpeed * Time.fixedDeltaTime, 0f);
            rb.MoveRotation(rb.rotation * deltaRotation);
            rb.angularVelocity = Vector3.zero;
        }

        void UpdateHeadRotation()
        {
            headBone.localRotation *= Quaternion.Euler(currentHeadPitch, currentHeadYaw, 0f);
        }
    }
}
