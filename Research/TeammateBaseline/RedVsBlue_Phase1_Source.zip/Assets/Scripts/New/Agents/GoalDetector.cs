using UnityEngine;

namespace RedVsBlue
{
    [RequireComponent(typeof(Rigidbody))]
    public class GoalDetector : MonoBehaviour
    {
        public event System.Action OnGoalReached;

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Goal"))
            {
                OnGoalReached?.Invoke();
                Debug.Log("Goal Reached");
            }
        }
    }
}
