using System.Collections.Generic;
using UnityEngine;

namespace RedVsBlue
{
    // Builds and owns one training area's Unity geometry (ground, walkable tiles, merged walls) for
    // a given Map, and is the authoritative source of walkability and grid<->world conversion for
    // everything else in that area.
    //
    // Walkability comes from the Map's own data, never from whether a rendering object exists --
    // the old InfluenceMap.GetTile(r,c) == null test meant the ML grid sensor was asking a Renderer
    // whether a cell was a wall. Tile Renderers are still owned here (this is what built them) and
    // lent to the influence map purely for painting.
    public class GridManager : MonoBehaviour
    {
        [SerializeField] private Transform wallPrefab;
        [SerializeField] private Transform groundPrefab;
        [SerializeField] private Transform gridTilePrefab;
        [SerializeField] private float gridUnitSize = 0.5f;
        [SerializeField] private int wallHeight = 6;

        private const string GeneratedGeometryName = "[Geometry]";

        // col/row are the top-left corner of a merged rectangle, in grid coordinates.
        private struct WallRect { public int col, row, width, height; }

        private Map _map;
        private Renderer[,] _tileRenderers;
        private float _originX;
        private float _originZ;

        public Map CurrentMap => _map;
        public int Rows => _map != null ? _map.Rows : 0;
        public int Cols => _map != null ? _map.Cols : 0;
        public float GridUnitSize => gridUnitSize;

        public bool IsInBounds(Vector2Int gridPos) => _map != null && _map.IsInBounds(gridPos.y, gridPos.x);
        public bool IsWalkable(int row, int col) => _map != null && _map.IsWalkable(row, col);
        public bool IsWalkable(Vector2Int gridPos) => IsWalkable(gridPos.y, gridPos.x);

        // Lent to InfluenceMap for per-tile tinting. Null for walls (no tile is built there).
        public Renderer GetTileRenderer(int row, int col) =>
            _tileRenderers != null && _map != null && _map.IsInBounds(row, col) ? _tileRenderers[row, col] : null;

        // Rebuilds all geometry for `map`. Safe to call repeatedly (a curriculum map switch) --
        // only the geometry child is destroyed, so agents parented elsewhere in the area survive.
        public void Build(Map map)
        {
            _map = map;
            if (map == null || map.Rows == 0 || map.Cols == 0)
            {
                Debug.LogError("[GridManager] Cannot build geometry: map is null or empty.");
                return;
            }

            Transform oldGeometry = transform.Find(GeneratedGeometryName);
            if (oldGeometry != null) Destroy(oldGeometry.gameObject);

            GameObject geometryGO = new(GeneratedGeometryName);
            geometryGO.transform.SetParent(transform, false);
            geometryGO.transform.localPosition = Vector3.zero;
            Transform geometry = geometryGO.transform;

            _originX = -(map.Cols * gridUnitSize) / 2f;
            _originZ = -(map.Rows * gridUnitSize) / 2f;

            Transform ground = Instantiate(groundPrefab, geometry);
            ground.localPosition = Vector3.zero;
            ground.localRotation = Quaternion.identity;
            SetWorldSize(ground, new Vector3(map.Cols * gridUnitSize, 1f, map.Rows * gridUnitSize));

            _tileRenderers = new Renderer[map.Rows, map.Cols];
            foreach (Vector2Int cell in map.WalkableCells)
            {
                Transform tile = Instantiate(gridTilePrefab, geometry);
                // GridTile is a Quad rotated 90 degrees about X (to lie flat), so its local X/Y axes
                // -- not X/Z -- are the visible face plane; local Z is the near-zero thickness.
                tile.localScale = new Vector3(gridUnitSize, gridUnitSize, tile.localScale.z);
                Vector2 local = GridToLocalXZ(cell.y, cell.x);
                tile.localPosition = new Vector3(local.x, 0.01f, local.y);
                _tileRenderers[cell.y, cell.x] = tile.GetComponentInChildren<Renderer>();
            }

            foreach (WallRect w in OptimiseWalls(map))
            {
                Transform wall = Instantiate(wallPrefab, geometry);
                SetWorldSize(wall, new Vector3(
                    w.width * gridUnitSize,
                    wallHeight * gridUnitSize,
                    w.height * gridUnitSize));
                wall.localPosition = new Vector3(
                    _originX + (w.col + w.width / 2f) * gridUnitSize,
                    wallHeight * gridUnitSize / 2f,
                    -(_originZ + (w.row + w.height / 2f) * gridUnitSize));
            }
        }

        public Vector2Int WorldToGrid(Vector3 worldPos)
        {
            Vector3 localPos = transform.InverseTransformPoint(worldPos);
            int col = Mathf.FloorToInt((localPos.x - _originX) / gridUnitSize);
            int row = Mathf.FloorToInt((-localPos.z - _originZ) / gridUnitSize);
            return new Vector2Int(col, row);
        }

        public Vector3 GridToWorld(Vector2Int gridPos)
        {
            Vector2 local = GridToLocalXZ(gridPos.y, gridPos.x);
            return transform.TransformPoint(new Vector3(local.x, 0f, local.y));
        }

        // Inverse of WorldToGrid, generalised to fractional row/col -- matches the same tile-centre
        // convention used when instantiating grid tiles.
        public Vector2 GridToLocalXZ(float row, float col)
        {
            float x = _originX + (col + 0.5f) * gridUnitSize;
            float z = -(_originZ + (row + 0.5f) * gridUnitSize);
            return new Vector2(x, z);
        }

        // Sets the world-space size of obj, correcting for the prefab's base mesh dimensions.
        // Skips any axis where the mesh has zero extent.
        private static void SetWorldSize(Transform obj, Vector3 desiredSize)
        {
            Vector3 meshSize = obj.GetComponentInChildren<Renderer>().bounds.size;
            Vector3 s = obj.localScale;
            obj.localScale = new Vector3(
                meshSize.x > 0.001f ? s.x * desiredSize.x / meshSize.x : s.x,
                meshSize.y > 0.001f ? s.y * desiredSize.y / meshSize.y : s.y,
                meshSize.z > 0.001f ? s.z * desiredSize.z / meshSize.z : s.z);
        }

        // Reduces wall object count by merging adjacent wall cells into axis-aligned rectangles:
        // walks column by column, finds vertical runs, and extends any run from the previous column
        // that starts at the same row and has the same height.
        private static List<WallRect> OptimiseWalls(Map map)
        {
            var result = new List<WallRect>();
            var active = new List<WallRect>();

            for (int c = 0; c < map.Cols; c++)
            {
                var runs = new List<(int startRow, int height)>();
                int r = 0;
                while (r < map.Rows)
                {
                    if (!map.IsWalkable(r, c))
                    {
                        int start = r;
                        while (r < map.Rows && !map.IsWalkable(r, c)) r++;
                        runs.Add((start, r - start));
                    }
                    else r++;
                }

                var newActive = new List<WallRect>();
                var matched = new bool[active.Count];

                foreach (var (startRow, height) in runs)
                {
                    bool found = false;
                    for (int i = 0; i < active.Count; i++)
                    {
                        if (!matched[i] && active[i].row == startRow && active[i].height == height)
                        {
                            WallRect ar = active[i];
                            ar.width++;
                            newActive.Add(ar);
                            matched[i] = true;
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        newActive.Add(new WallRect { col = c, row = startRow, width = 1, height = height });
                }

                for (int i = 0; i < active.Count; i++)
                    if (!matched[i]) result.Add(active[i]);

                active = newActive;
            }

            result.AddRange(active);
            return result;
        }
    }
}
