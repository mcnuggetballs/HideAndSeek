using System.Collections.Generic;
using UnityEngine;

namespace RedVsBlue
{
    // Thin composition root for one training area. Resolves its three components, holds the
    // curriculum delegates, and drives the load/run cycle. Deliberately holds no reward, geometry
    // or progression logic of its own -- it only routes between the area and the curriculum.
    //
    // Areas are fully independent: one area finishing an episode never touches another.
    public class TrainingAreaManager : MonoBehaviour
    {
        [SerializeField] private GridManager grid;
        [SerializeField] private InfluenceMap influenceMap;
        [SerializeField] private EpisodeManager episodes;

        // Assigned by SimulationManager, pointing at the shared Curriculum. See ICurriculumStrategy
        // for the two-step contract: report first, and only fetch new data if that says something
        // actually changed.
        public ReportResultsDelegate reportResults;
        public TryGetNextEpisodeDelegate tryGetNextEpisode;

        // Read-only shared map list. Needed because the curriculum communicates in map INDICES, and
        // this area has to resolve one to an actual Map to build geometry. Shared immutable data,
        // not a control coupling -- progression decisions still arrive only through the delegates.
        private IReadOnlyList<Map> _maps;

        private EpisodeConstructionData _current;
        private int _builtMapIndex = -1;

        public void Initialise(IReadOnlyList<Map> maps, int areaId)
        {
            _maps = maps;

            if (grid == null) grid = GetComponentInChildren<GridManager>(true);
            if (influenceMap == null) influenceMap = GetComponentInChildren<InfluenceMap>(true);
            if (episodes == null) episodes = GetComponentInChildren<EpisodeManager>(true);

            if (grid == null || episodes == null)
            {
                Debug.LogError($"[TrainingAreaManager] '{name}' is missing a GridManager or EpisodeManager.");
                return;
            }

            episodes.Initialise(grid, influenceMap, areaId);
            episodes.Finished += OnEpisodeFinished;
        }

        private void OnDestroy()
        {
            if (episodes != null) episodes.Finished -= OnEpisodeFinished;
        }

        // Builds whatever this episode needs and places every agent. Geometry is only rebuilt when
        // the map actually changed -- repositioning agents on the same map is much cheaper than
        // tearing down and re-instantiating all the tiles and walls.
        public void Load(EpisodeConstructionData data)
        {
            _current = data;

            if (_maps == null || data.mapIndex < 0 || data.mapIndex >= _maps.Count)
            {
                Debug.LogError($"[TrainingAreaManager] '{name}' got mapIndex {data.mapIndex}, which is out of range.");
                return;
            }

            if (data.mapIndex != _builtMapIndex)
            {
                grid.Build(_maps[data.mapIndex]);
                if (influenceMap != null) influenceMap.Initialise(grid);
                _builtMapIndex = data.mapIndex;
            }

            episodes.Begin(data);
        }

        public void StartRun() => episodes.StartRun();

        private void OnEpisodeFinished(EpisodeResults results)
        {
            // Report first. A static curriculum answers false here, meaning nothing about the next
            // episode differs -- so we skip the fetch entirely and just re-run the stored data.
            bool changed = reportResults != null && reportResults(results);

            if (changed && tryGetNextEpisode != null)
            {
                if (!tryGetNextEpisode(out EpisodeConstructionData next, results))
                {
                    Debug.Log($"[TrainingAreaManager] '{name}': curriculum reports simulation finished.");
                    return;
                }
                _current = next;
            }

            Load(_current);
            StartRun();
        }
    }
}
