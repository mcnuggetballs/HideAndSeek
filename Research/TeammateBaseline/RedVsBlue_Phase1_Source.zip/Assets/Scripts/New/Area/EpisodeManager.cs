using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;

namespace RedVsBlue
{
    // Owns one training area's episode lifecycle: places blue agents and hiders from an
    // EpisodeConstructionData, awards every reward, counts steps, and decides when the episode is
    // over.
    //
    // This is the SINGLE owner of reward logic. Agents never call AddReward on themselves -- in the
    // old code rewards were spread across MultiBlueAgentSearch, MultiAgentEnvironmentManager and
    // AgentController, which made the total signal impossible to read off any one file.
    public class EpisodeManager : MonoBehaviour
    {
        [Header("Prefabs")]
        [SerializeField] private Transform blueAgentPrefab;
        [SerializeField] private Transform hiderPrefab;

        // Team size is NOT configured here -- it's however many locations the curriculum supplied in
        // the EpisodeConstructionData. One source of truth, and it lets a strategy vary team size
        // across the curriculum without a second setting having to be kept in sync.

        // Owned here, not on the agent's BehaviorParameters (which should be MaxStep = 0). Unity's
        // guidance for grouped agents is to manage timing at the group level, and it lets a timeout
        // end as a TRUNCATION (GroupEpisodeInterrupted) rather than a termination -- which matters
        // for MA-POCA's value bootstrapping. Previously every agent independently hit MaxStep 2048.
        [SerializeField] private int maxSteps = 2048;

        // Suppresses BOTH ways an episode can end, for the inference/testing scene where you want to
        // watch a policy run continuously instead of being teleported back to spawn every reset.
        // Caught hiders simply stay caught.
        //
        // Must stay OFF for training: a trajectory with no boundaries gives the trainer nothing to
        // bootstrap from. As a side effect nothing ever reaches Finish(), so the curriculum is never
        // re-queried and never writes its progress file -- which is why an inference run can't
        // corrupt training progression.
        [Tooltip("Testing/inference only: never end the episode. Must stay OFF for training.")]
        [SerializeField] private bool endlessEpisode = false;

        [Header("Rewards")]
        [SerializeField] private float timePressurePenalty = 2f;
        [SerializeField] private float hiderCaughtReward = 5f;

        // The agent that actually makes the catch gets this fraction of hiderCaughtReward as its own
        // cut, on top of the full group share every member receives.
        [SerializeField] private float individualCatchRewardFraction = 0.5f;

        [SerializeField] private float isolationPenalty = 0.005f;
        [SerializeField] private int teammateProximityTiles = 8;

        private readonly SimpleMultiAgentGroup _group = new();
        private readonly List<Transform> _blueAgents = new();
        private readonly List<Agent> _blueAgentComponents = new();
        private readonly List<RedAgent> _hiders = new();

        private readonly List<Vector2Int> _caughtCells = new();

        private GridManager _grid;
        private InfluenceMap _influenceMap;
        private int _areaId;
        private int _step;
        private int _hidersCaught;
        private int _hiderCount;
        private int _mapIndex;
        private float _groupReward;
        private bool _running;

        public event Action<EpisodeResults> Finished;
        public IReadOnlyList<Transform> BlueAgents => _blueAgents;

        // Published so observers can agree on a hider's id: a sighting is broadcast team-wide under
        // one id, so every agent must derive the same one. List position is that id -- stable for
        // the run, since instances are reused rather than recreated.
        public IReadOnlyList<RedAgent> Hiders => _hiders;

        public void Initialise(GridManager grid, InfluenceMap influenceMap, int areaId)
        {
            _grid = grid;
            _influenceMap = influenceMap;
            _areaId = areaId;
        }

        // Places everything for one episode. Instances are created on the first call and reused
        // (repositioned) forever after, so each agent's group registration and assigned id stay
        // stable for the lifetime of the run.
        public void Begin(EpisodeConstructionData data)
        {
            if (data.agentLocations == null || data.agentLocations.Length == 0 ||
                data.hiderLocations == null || data.hiderLocations.Length == 0)
            {
                Debug.LogError("[EpisodeManager] EpisodeConstructionData has no agent or hider locations.");
                return;
            }

            _running = false;
            _step = 0;
            _hidersCaught = 0;
            _hiderCount = data.hiderLocations.Length;
            _groupReward = 0f;
            _mapIndex = data.mapIndex;
            _caughtCells.Clear();

            if (_influenceMap != null)
            {
                _influenceMap.ResetLayers();
                // Must come AFTER ResetLayers -- that recreates every layer object, so anything
                // pushed before it would be discarded.
                PushSpawnVisualisation(data);
            }

            // See RedAgent.SetColliderEnabled for why the whole placement window runs with hider
            // colliders off.
            foreach (RedAgent hider in _hiders) hider.SetColliderEnabled(false);

            PlaceBlueAgents(data.agentLocations);
            PlaceHiders(data.hiderLocations);

            foreach (RedAgent hider in _hiders) hider.SetColliderEnabled(true);
        }

        public void StartRun() => _running = true;

        // Feeds the two spawn debug layers from whatever pool the curriculum drew this episode's
        // hiders out of. Re-pushed every episode because ResetLayers wipes the layer data, and the
        // pool changes whenever blue moves (the band is measured from blue's positions).
        //
        // Grid coords arrive as Vector2Int(x = col, y = row); the InfluenceMap API takes (row, col)
        // tuples, hence the flip.
        private void PushSpawnVisualisation(EpisodeConstructionData data)
        {
            if (data.hiderCandidates == null || data.hiderCandidates.Length == 0) return;

            List<(int row, int col)> cells = new(data.hiderCandidates.Length);
            foreach (Vector2Int cell in data.hiderCandidates)
                cells.Add((cell.y, cell.x));
            _influenceMap.SetRedSpawnCandidates(cells);

            float[] weights = data.hiderCandidateWeights;
            if (weights == null || weights.Length != data.hiderCandidates.Length) return;

            Dictionary<(int row, int col), float> weighted = new(data.hiderCandidates.Length);
            for (int i = 0; i < data.hiderCandidates.Length; i++)
                weighted[(data.hiderCandidates[i].y, data.hiderCandidates[i].x)] = weights[i];
            _influenceMap.SetRedSpawnProbabilities(weighted);
        }

        private void PlaceBlueAgents(Vector2Int[] locations)
        {
            for (int i = 0; i < locations.Length; i++)
            {
                if (i >= _blueAgents.Count)
                {
                    Transform instance = Instantiate(blueAgentPrefab, transform);

                    // Ids are 1-based, matching the instance's position in the list at the moment
                    // it's added -- AgentPositionsLayer uses 0 as its "empty tile" sentinel.
                    if (instance.TryGetComponent(out AgentController controller))
                        controller.Initialise(_influenceMap, _grid, _blueAgents.Count + 1);

                    _blueAgents.Add(instance);

                    if (instance.TryGetComponent(out Agent agent))
                    {
                        _blueAgentComponents.Add(agent);
                        _group.RegisterAgent(agent);
                    }
                    else
                    {
                        Debug.LogError("[EpisodeManager] Blue agent prefab has no Agent component; it cannot be trained.");
                    }
                }

                Place(_blueAgents[i], locations[i]);
            }
        }

        private void PlaceHiders(Vector2Int[] locations)
        {
            for (int i = 0; i < locations.Length; i++)
            {
                if (i >= _hiders.Count)
                {
                    Transform instance = Instantiate(hiderPrefab, transform);
                    RedAgent hider = instance.GetComponent<RedAgent>();
                    if (hider == null)
                    {
                        Debug.LogError("[EpisodeManager] Hider prefab has no RedAgent component.");
                        return;
                    }
                    hider.Initialise(this);
                    _hiders.Add(hider);
                }

                // Caught hiders deactivate themselves, so every episode has to switch them back on.
                _hiders[i].gameObject.SetActive(true);
                _hiders[i].SetColliderEnabled(false);
                Place(_hiders[i].transform, locations[i]);
            }

            // A curriculum may ask for fewer hiders than a previous episode used; park the surplus
            // rather than leaving stale instances catchable on the map.
            for (int i = locations.Length; i < _hiders.Count; i++)
                _hiders[i].gameObject.SetActive(false);
        }

        private void Place(Transform target, Vector2Int gridPos)
        {
            target.position = _grid.GridToWorld(gridPos);
            target.rotation = Quaternion.Euler(0f, UnityEngine.Random.Range(0f, 360f), 0f);
            if (target.TryGetComponent(out Rigidbody body))
            {
                body.linearVelocity = Vector3.zero;
                body.angularVelocity = Vector3.zero;
            }
        }

        // FixedUpdate, not Update: ML-Agents' Academy steps on a FixedUpdate stepper, so one call
        // here is one environment step. The old code ran this in Update() -- once per RENDERED frame,
        // a cadence that drifts from the true step rate in both directions -- and needed a
        // StepCount-delta scaling hack to compensate. Counting on the physics tick removes the need
        // for that entirely.
        private void FixedUpdate()
        {
            if (!_running) return;

            _step++;
            UpdateAgentPerception();

            // The maxSteps > 0 guards are load-bearing, not defensive noise: at maxSteps = 0 this
            // division yields -Infinity and poisons every group reward, and `_step >= 0` would end
            // the episode on its first step. Both fire together for anyone reaching for the
            // "0 = unlimited" convention ML-Agents itself uses for Agent.MaxStep.
            if (maxSteps > 0) AddGroupReward(-timePressurePenalty / maxSteps);
            ApplyIsolationPenalty();

            if (!endlessEpisode && maxSteps > 0 && _step >= maxSteps) Finish(interrupted: true);
        }

        // Drives every agent's per-step perception. The two passes are load-bearing and must NOT be
        // merged into one loop: an agent's LOS sweep reads the AgentPositions layer to work out which
        // teammates it can see, so every agent's position has to already be current before ANY agent
        // looks. Interleaving them would have agent 1 seeing agent 2 at last step's position.
        //
        // UpdateLayers() runs once at the end, after all observations are in, so the per-tile
        // time-since-last-seen decay is applied exactly once per environment step.
        private void UpdateAgentPerception()
        {
            if (_influenceMap == null || _grid == null) return;

            for (int i = 0; i < _blueAgents.Count; i++)
            {
                if (_blueAgents[i] == null) continue;
                if (!_blueAgents[i].TryGetComponent(out AgentController controller)) continue;

                Vector2Int gridPos = _grid.WorldToGrid(_blueAgents[i].position);
                if (_grid.IsInBounds(gridPos))
                    _influenceMap.UpdateAgentPosition(gridPos, controller.GetAgentId());
            }

            for (int i = 0; i < _blueAgents.Count; i++)
            {
                if (_blueAgents[i] == null) continue;
                if (_blueAgents[i].TryGetComponent(out AgentController controller))
                    controller.UpdateAgentObservations();
            }

            _influenceMap.UpdateLayers();
        }

        // Flat per-step penalty on any agent with no teammate within teammateProximityTiles. Uses a
        // real walking-distance check (Map.AreTilesWithinHops), so two agents either side of a wall
        // count as isolated even when they're physically adjacent. Individual, not group: it's a
        // per-agent behaviour being shaped.
        private void ApplyIsolationPenalty()
        {
            if (isolationPenalty <= 0f || _blueAgents.Count < 2) return;

            Map map = _grid.CurrentMap;
            if (map == null) return;

            for (int i = 0; i < _blueAgents.Count; i++)
            {
                Vector2Int myPos = _grid.WorldToGrid(_blueAgents[i].position);
                bool hasNearbyTeammate = false;

                for (int j = 0; j < _blueAgents.Count && !hasNearbyTeammate; j++)
                {
                    if (i == j) continue;
                    Vector2Int otherPos = _grid.WorldToGrid(_blueAgents[j].position);
                    hasNearbyTeammate = map.AreTilesWithinHops(myPos, otherPos, teammateProximityTiles);
                }

                if (!hasNearbyTeammate) _blueAgentComponents[i].AddReward(-isolationPenalty);
            }
        }

        public void NotifyHiderCaught(RedAgent hider, Agent catcher)
        {
            if (!_running) return;

            _hidersCaught++;

            // Recorded here rather than derived later: the hider deactivates itself on capture, so
            // this is the last moment its position means anything. Batched into EpisodeResults so the
            // curriculum can weight future spawns away from cells that keep yielding catches.
            _caughtCells.Add(_grid.WorldToGrid(hider.transform.position));

            AddGroupReward(hiderCaughtReward);
            catcher.AddReward(hiderCaughtReward * individualCatchRewardFraction);

            if (!endlessEpisode && _hidersCaught >= _hiderCount) Finish(interrupted: false);
        }

        // AddGroupReward applies the FULL amount to every registered member rather than dividing it,
        // so this must be called once per event -- never once per agent, which would multiply it by
        // team size.
        private void AddGroupReward(float reward)
        {
            _group.AddGroupReward(reward);
            _groupReward += reward;
        }

        // Closes the ML-Agents trajectory BEFORE anything repositions agents, so the final rewards
        // land on the episode that earned them. TrainingAreaManager then handles what runs next.
        private void Finish(bool interrupted)
        {
            _running = false;

            if (interrupted) _group.GroupEpisodeInterrupted();
            else _group.EndGroupEpisode();

            Finished?.Invoke(new EpisodeResults
            {
                mapIndex = _mapIndex,
                areaId = _areaId,
                allHidersCaught = _hidersCaught >= _hiderCount,
                hidersCaught = _hidersCaught,
                steps = _step,
                groupReward = _groupReward,
                hiderCaughtCells = _caughtCells.ToArray(),
            });
        }
    }
}
